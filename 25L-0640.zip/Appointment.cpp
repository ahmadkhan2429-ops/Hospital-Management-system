#include "Appointment.h"

Appointment::Appointment() : appointmentId(0), patientId(0), doctorId(0) {}
Appointment::Appointment(int aid, int pid, int did,
    const std::string& date, const std::string& slot, const std::string& status)
    : appointmentId(aid), patientId(pid), doctorId(did), date(date), timeSlot(slot), status(status) {
}

int         Appointment::getId()            const { return appointmentId; }
int         Appointment::getAppointmentId() const { return appointmentId; }
int         Appointment::getPatientId()     const { return patientId; }
int         Appointment::getDoctorId()      const { return doctorId; }
std::string Appointment::getDate()          const { return date; }
std::string Appointment::getTimeSlot()      const { return timeSlot; }
std::string Appointment::getStatus()        const { return status; }

void Appointment::setStatus(const std::string& s) { status = s; }
void Appointment::setAppointmentId(int i) { appointmentId = i; }
void Appointment::setPatientId(int i) { patientId = i; }
void Appointment::setDoctorId(int i) { doctorId = i; }
void Appointment::setDate(const std::string& d) { date = d; }
void Appointment::setTimeSlot(const std::string& t) { timeSlot = t; }

// Conflict: same doc, same date, same slot, NEITHER cancelled
bool Appointment::operator==(const Appointment& o) const {
    if (doctorId != o.doctorId) return false;
    if (date != o.date) return false;
    if (timeSlot != o.timeSlot) return false;
    if (status == "cancelled" || o.status == "cancelled") return false;
    return true;
}

std::ostream& operator<<(std::ostream& os, const Appointment& a) {
    os << "[" << a.appointmentId << "] P:" << a.patientId
        << " D:" << a.doctorId << " " << a.date << " " << a.timeSlot << " " << a.status;
    return os;
}
