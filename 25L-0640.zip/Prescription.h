#pragma once
#include <string>

class Prescription {
private:
    int         prescriptionId, appointmentId, patientId, doctorId;
    std::string date, medicines, notes;
public:
    Prescription();
    Prescription(int presId, int apptId, int patId, int docId,
        const std::string& date, const std::string& medicines, const std::string& notes);

    int         getId()             const;
    int         getPrescriptionId() const;
    int         getAppointmentId()  const;
    int         getPatientId()      const;
    int         getDoctorId()       const;
    std::string getDate()           const;
    std::string getMedicines()      const;
    std::string getNotes()          const;

    void setPrescriptionId(int i);
    void setAppointmentId(int i);
    void setPatientId(int i);
    void setDoctorId(int i);
    void setDate(const std::string& d);
    void setMedicines(const std::string& m);
    void setNotes(const std::string& n);
};