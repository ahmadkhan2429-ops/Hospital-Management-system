#pragma once
#include <string>

class Validator {
public:
    static bool        isValidDate(const std::string& date);
    static bool        isValidTimeSlot(const std::string& slot);
    static bool        isValidContact(const std::string& contact);
    static bool        isValidPassword(const std::string& pw);
    static bool        isPositiveFloat(const std::string& s, float& out);
    static bool        isPositiveInt(const std::string& s, int& out);
    static bool        isValidMenuChoice(const std::string& s, int mn, int mx, int& out);
    static std::string toLowerStr(const std::string& s);
    static bool        strEqualCI(const std::string& a, const std::string& b);
    static std::string todayString();
    static int         compareDates(const std::string& a, const std::string& b);
    static int         daysBetween(const std::string& a, const std::string& b);
};