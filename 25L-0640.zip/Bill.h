#pragma once
#include <string>

class Bill {
private:
    int         billId, patientId, appointmentId;
    float       amount;
    std::string status, date;
public:
    Bill();
    Bill(int bid, int pid, int aid, float amount,
        const std::string& status, const std::string& date);

    int         getId()            const;
    int         getBillId()        const;
    int         getPatientId()     const;
    int         getAppointmentId() const;
    float       getAmount()        const;
    std::string getStatus()        const;
    std::string getDate()          const;

    void setBillId(int i);
    void setStatus(const std::string& s);
    void setAmount(float a);
    void setPatientId(int i);
    void setAppointmentId(int i);
    void setDate(const std::string& d);
};