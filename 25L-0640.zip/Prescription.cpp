#include "Prescription.h"
Prescription::Prescription() : prescriptionId(0), appointmentId(0), patientId(0), doctorId(0) {}
Prescription::Prescription(int presId, int apptId, int patId, int docId,
    const std::string& date, const std::string& medicines, const std::string& notes)
    : prescriptionId(presId), appointmentId(apptId), patientId(patId),
    doctorId(docId), date(date), medicines(medicines), notes(notes) {
}

int         Prescription::getId()             const { return prescriptionId; }
int         Prescription::getPrescriptionId() const { return prescriptionId; }
int         Prescription::getAppointmentId()  const { return appointmentId; }
int         Prescription::getPatientId()      const { return patientId; }
int         Prescription::getDoctorId()       const { return doctorId; }
std::string Prescription::getDate()           const { return date; }
std::string Prescription::getMedicines()      const { return medicines; }
std::string Prescription::getNotes()          const { return notes; }

void Prescription::setPrescriptionId(int i) { prescriptionId = i; }
void Prescription::setAppointmentId(int i) { appointmentId = i; }
void Prescription::setPatientId(int i) { patientId = i; }
void Prescription::setDoctorId(int i) { doctorId = i; }
void Prescription::setDate(const std::string& d) { date = d; }
void Prescription::setMedicines(const std::string& m) { medicines = m; }
void Prescription::setNotes(const std::string& n) { notes = n; }
