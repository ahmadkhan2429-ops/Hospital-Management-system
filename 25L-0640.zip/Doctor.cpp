#include "Doctor.h"
#include <iostream>

Doctor::Doctor() : Person(), fee(0.f) {}
Doctor::Doctor(int id, const std::string& name, const std::string& spec,
    const std::string& contact, const std::string& password, float fee)
    : Person(id, name, password, contact), specialization(spec), fee(fee) {
}

std::string Doctor::getSpecialization() const { return specialization; }
float       Doctor::getFee()            const { return fee; }
void Doctor::setSpecialization(const std::string& s) { specialization = s; }
void Doctor::setFee(float f) { fee = f; }

bool Doctor::operator==(const Doctor& o) const { return id == o.id; }

std::ostream& operator<<(std::ostream& os, const Doctor& d) {
    os << "[" << d.id << "] Dr." << d.name
        << " | " << d.specialization << " | " << d.contact << " | PKR " << d.fee;
    return os;
}

void Doctor::displayMenu() { /* handled in GUI */ }
std::string Doctor::getRole() const { return "Doctor"; }
