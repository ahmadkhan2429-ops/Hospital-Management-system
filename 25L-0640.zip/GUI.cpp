﻿#include "GUI.h"
#include "FileHandler.h"
#include "Validator.h"
#include "HospitalException.h"
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <cmath>

// ─────────────────────────────────────────────────────────────────────────────
// Constructor
// ─────────────────────────────────────────────────────────────────────────────
GUI::GUI(Storage<Patient>& p, Storage<Doctor>& d,
    Storage<Appointment>& a, Storage<Bill>& b,
    Storage<Prescription>& pr, Admin& admin)
    : window(sf::VideoMode(1200u, 780u),
        "MediCore - Hospital Management System",
        sf::Style::Close | sf::Style::Titlebar),
    currentScreen(Screen::MAIN_MENU),
    patients(p), doctors(d), appointments(a),
    bills(b), prescriptions(pr), adminData(admin)
{
    window.setFramerateLimit(60u);

    // Load PressStart2P font — must be in same folder as .exe
    if (!font.loadFromFile("PressStart2P-Regular.ttf")) {
        // fallback fonts for testing
        if (!font.loadFromFile("C:/Windows/Fonts/arial.ttf"))
            font.loadFromFile("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf");
    }
    buildMainMenu();
}

// ─────────────────────────────────────────────────────────────────────────────
// Run loop
// ─────────────────────────────────────────────────────────────────────────────
void GUI::run() {
    while (window.isOpen()) {
        sf::Event ev;
        while (window.pollEvent(ev)) {
            if (ev.type == sf::Event::Closed) window.close();

            if (ev.type == sf::Event::MouseButtonPressed
                && ev.mouseButton.button == sf::Mouse::Left) {
                sf::Vector2i m = sf::Mouse::getPosition(window);
                updateHovers(m);
                processClicks(m);
                // Input focus
                for (int i = 0; i < static_cast<int>(inputs.size()); i++) {
                    if (inputs[i].box.getGlobalBounds()
                        .contains(static_cast<float>(m.x), static_cast<float>(m.y))) {
                        activeInputIdx = i;
                        for (auto& inp : inputs) inp.active = false;
                        inputs[i].active = true;
                    }
                }
            }

            if (ev.type == sf::Event::MouseMoved)
                updateHovers(sf::Mouse::getPosition(window));

            if (ev.type == sf::Event::TextEntered
                && activeInputIdx >= 0
                && activeInputIdx < static_cast<int>(inputs.size())) {
                sf::Uint32 c = ev.text.unicode;
                if (c == 8u) {
                    if (!inputs[activeInputIdx].value.empty())
                        inputs[activeInputIdx].value.pop_back();
                }
                else if (c >= 32u && c < 127u) {
                    inputs[activeInputIdx].value += static_cast<char>(c);
                }
            }

            if (ev.type == sf::Event::MouseWheelScrolled) {
                scrollY -= ev.mouseWheelScroll.delta * 30.f;
                if (scrollY < 0.f)       scrollY = 0.f;
                if (scrollY > maxScrollY) scrollY = maxScrollY;
            }
        }
        render();
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Drawing helpers
// ─────────────────────────────────────────────────────────────────────────────
void GUI::drawRect(float x, float y, float w, float h,
    sf::Color fill, sf::Color borderCol, float borderThick) {
    sf::RectangleShape r(sf::Vector2f(w, h));
    r.setPosition(x, y);
    r.setFillColor(fill);
    if (borderThick > 0.f) {
        r.setOutlineColor(borderCol);
        r.setOutlineThickness(borderThick);
    }
    window.draw(r);
}

void GUI::drawText(const std::string& txt, float x, float y,
    unsigned sz, sf::Color col,
    bool bold, bool center, float maxW) {
    if (txt.empty()) return;
    sf::Text t;
    t.setFont(font);
    t.setString(txt);
    t.setCharacterSize(sz);
    t.setFillColor(col);
    if (bold) t.setStyle(sf::Text::Bold);
    if (center && maxW > 0.f) {
        float tw = t.getLocalBounds().width;
        x += (maxW - tw) / 2.f;
    }
    t.setPosition(x, y);
    window.draw(t);
}

void GUI::drawHeader(const std::string& title, const std::string& sub) {
    // Top bar
    drawRect(0.f, 0.f, 1200.f, 75.f, sf::Color(8, 12, 28));
    // Green accent line
    drawRect(0.f, 75.f, 1200.f, 3.f, PRIMARY);

    // Logo box
    drawRect(14.f, 10.f, 50.f, 50.f, PRIMARY);
    drawText("M", 22.f, 14.f, 10u, sf::Color(8, 12, 28), true);
    drawText("C", 22.f, 32.f, 10u, sf::Color(8, 12, 28), true);

    drawText("MEDICORE", 74.f, 14.f, 10u, PRIMARY, true);
    drawText("Hospital Management System", 74.f, 42.f, 7u, TEXT_DIM);

    // Page title centered
    drawText(title, 300.f, 16.f, 11u, TEXT_MAIN, true, true, 600.f);
    if (!sub.empty())
        drawText(sub, 300.f, 46.f, 7u, TEXT_DIM, false, true, 600.f);

    // Status banner just below header
    if (!statusMsg.empty()) {
        sf::Color sbg = statusIsError ? sf::Color(120, 20, 20, 230)
            : sf::Color(15, 90, 50, 230);
        drawRect(0.f, 78.f, 1200.f, 28.f, sbg);
        drawText(statusMsg, 12.f, 83.f, 7u, sf::Color::White);
    }
}

void GUI::drawScrollPane(const std::string& content,
    float x, float y, float w, float h) {
    drawRect(x, y, w, h, CARD, BORDER, 1.5f);

    float lineH = 22.f;
    std::istringstream ss(content);
    std::string line;
    int lineNum = 0;
    float totalH = 0.f;

    // First pass — count lines for maxScrollY
    while (std::getline(ss, line)) lineNum++;
    totalH = static_cast<float>(lineNum) * lineH;
    maxScrollY = (totalH > h) ? totalH - h + 20.f : 0.f;

    // Second pass — draw
    std::istringstream ss2(content);
    lineNum = 0;
    while (std::getline(ss2, line)) {
        float lineY = y + 8.f + static_cast<float>(lineNum) * lineH - scrollY;
        lineNum++;
        if (lineY + lineH < y || lineY > y + h) continue;

        // Alternating row tint
        if (lineNum % 2 == 0)
            drawRect(x + 2.f, lineY, w - 4.f, lineH - 1.f,
                sf::Color(35, 50, 70, 80));

        sf::Color col = TEXT_MAIN;
        if (line.find("OVERDUE") != std::string::npos) col = DANGER;
        else if (line.find("===") != std::string::npos) col = PRIMARY;
        else if (line.find("---") != std::string::npos) col = BORDER;

        drawText(line, x + 8.f, lineY + 2.f, 8u, col);
    }
}

UIButton GUI::makeButton(const std::string& lbl,
    float x, float y, float w, float h,
    sf::Color bg, sf::Color fg) {
    UIButton btn;
    btn.normalColor = bg;
    btn.hoverColor = sf::Color(
        static_cast<sf::Uint8>(std::min(255, static_cast<int>(bg.r) + 35)),
        static_cast<sf::Uint8>(std::min(255, static_cast<int>(bg.g) + 35)),
        static_cast<sf::Uint8>(std::min(255, static_cast<int>(bg.b) + 35)));
    btn.shape.setSize(sf::Vector2f(w, h));
    btn.shape.setPosition(x, y);
    btn.shape.setFillColor(bg);
    btn.label.setFont(font);
    btn.label.setString(lbl);
    btn.label.setCharacterSize(8u);
    btn.label.setFillColor(fg);
    btn.label.setStyle(sf::Text::Bold);
    float tw = btn.label.getLocalBounds().width;
    float th = btn.label.getLocalBounds().height;
    btn.label.setPosition(x + (w - tw) / 2.f, y + (h - th) / 2.f - 4.f);
    return btn;
}

UIInput GUI::makeInput(const std::string& lbl,
    float x, float y, float w,
    const std::string& ph, bool password) {
    UIInput inp;
    inp.box.setSize(sf::Vector2f(w, 36.f));
    inp.box.setPosition(x, y + 20.f);
    inp.box.setFillColor(sf::Color(20, 30, 55));
    inp.box.setOutlineColor(BORDER);
    inp.box.setOutlineThickness(1.5f);
    inp.labelText.setFont(font);
    inp.labelText.setString(lbl);
    inp.labelText.setCharacterSize(7u);
    inp.labelText.setFillColor(TEXT_DIM);
    inp.labelText.setPosition(x, y);
    inp.placeholder = ph;
    inp.isPassword = password;
    return inp;
}

void GUI::clearUI() {
    buttons.clear();
    inputs.clear();
    activeInputIdx = -1;
    scrollY = 0.f;
    maxScrollY = 0.f;
    infoBody.clear();
    statusMsg.clear();
}

void GUI::updateHovers(sf::Vector2i mouse) {
    for (auto& btn : buttons) {
        bool over = btn.shape.getGlobalBounds().contains(
            static_cast<float>(mouse.x), static_cast<float>(mouse.y));
        btn.hovered = over;
        btn.shape.setFillColor(over ? btn.hoverColor : btn.normalColor);
    }
}

void GUI::processClicks(sf::Vector2i mouse) {
    for (auto& btn : buttons) {
        if (btn.shape.getGlobalBounds().contains(
            static_cast<float>(mouse.x), static_cast<float>(mouse.y))) {
            if (btn.onClick) btn.onClick();
            return;
        }
    }
}

void GUI::goTo(Screen s) {
    currentScreen = s;
    clearUI();
    scrollY = 0.f;
    switch (s) {
    case Screen::MAIN_MENU:         buildMainMenu();          break;
    case Screen::PATIENT_LOGIN:     buildLoginScreen("Patient"); break;
    case Screen::DOCTOR_LOGIN:      buildLoginScreen("Doctor");  break;
    case Screen::ADMIN_LOGIN:       buildLoginScreen("Admin");   break;
    case Screen::PATIENT_MENU:      buildPatientMenu();       break;
    case Screen::DOCTOR_MENU:       buildDoctorMenu();        break;
    case Screen::ADMIN_MENU:        buildAdminMenu();         break;
    case Screen::BOOK_APPT:         buildBookAppt();          break;
    case Screen::CANCEL_APPT:       buildCancelAppt();        break;
    case Screen::VIEW_APPTS:        buildViewAppts();         break;
    case Screen::VIEW_RECORDS:      buildViewRecords();       break;
    case Screen::VIEW_BILLS:        buildViewBills();         break;
    case Screen::PAY_BILL:          buildPayBill();           break;
    case Screen::TOPUP:             buildTopUp();             break;
    case Screen::DOC_TODAY:         buildDocToday();          break;
    case Screen::DOC_COMPLETE:      buildDocComplete();       break;
    case Screen::DOC_NOSHOW:        buildDocNoShow();         break;
    case Screen::DOC_PRESCRIPTION:  buildDocPrescription();   break;
    case Screen::DOC_HISTORY:       buildDocHistory();        break;
    case Screen::ADM_ADD_DOCTOR:    buildAdmAddDoctor();      break;
    case Screen::ADM_REMOVE_DOCTOR: buildAdmRemoveDoctor();   break;
    case Screen::ADM_VIEW_PATIENTS: buildAdmViewPatients();   break;
    case Screen::ADM_VIEW_DOCTORS:  buildAdmViewDoctors();    break;
    case Screen::ADM_VIEW_APPTS:    buildAdmViewAppts();      break;
    case Screen::ADM_UNPAID_BILLS:  buildAdmUnpaidBills();    break;
    case Screen::ADM_DISCHARGE:     buildAdmDischarge();      break;
    case Screen::ADM_SECURITY_LOG:  buildAdmSecurityLog();    break;
    case Screen::ADM_DAILY_REPORT:  buildAdmDailyReport();    break;
    }
}

void GUI::setStatus(const std::string& msg, bool error) {
    statusMsg = msg;
    statusIsError = error;
}

std::string GUI::formatCurrency(float f) {
    std::ostringstream ss;
    ss << "PKR " << std::fixed << std::setprecision(2) << f;
    return ss.str();
}

template<typename T>
int GUI::nextId(Storage<T>& s) {
    int mx = 0;
    for (int i = 0; i < s.size(); i++) {
        int id = s.get(i)->getId();
        if (id > mx) mx = id;
    }
    return mx + 1;
}

// ─────────────────────────────────────────────────────────────────────────────
// Screen builders
// ─────────────────────────────────────────────────────────────────────────────

void GUI::buildMainMenu() {
    // Three big role cards
    struct Card { const char* lbl; const char* sub; Screen sc; sf::Color col; float x; };
    Card cards[] = {
        {"PATIENT",  "Book appointments\nView records",      Screen::PATIENT_LOGIN, PRIMARY,   80.f},
        {"DOCTOR",   "Manage schedule\nWrite prescriptions", Screen::DOCTOR_LOGIN,  SECONDARY, 430.f},
        {"ADMIN",    "Full system\ncontrol",                 Screen::ADMIN_LOGIN,   DANGER,    780.f},
    };
    for (auto& c : cards) {
        // Card background
        drawRect(c.x, 220.f, 320.f, 260.f, CARD, c.col, 2.f); // drawn in render
        auto btn = makeButton(c.lbl, c.x + 40.f, 380.f, 240.f, 50.f, c.col, sf::Color(8, 12, 28));
        Screen s = c.sc;
        btn.onClick = [this, s] { loginAttempts = 0; goTo(s); };
        buttons.push_back(btn);
    }
    auto btnExit = makeButton("EXIT", 510.f, 560.f, 180.f, 44.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnExit.onClick = [this] { window.close(); };
    buttons.push_back(btnExit);
}

void GUI::buildLoginScreen(const std::string& role) {
    float x = 300.f, y = 160.f;
    inputs.push_back(makeInput(role + " ID", x, y, 600.f));
    inputs.push_back(makeInput("Password", x, y + 90.f, 600.f, "", true));

    sf::Color col = (role == "Patient") ? PRIMARY :
        (role == "Doctor") ? SECONDARY : DANGER;

    auto btnLogin = makeButton("LOGIN", x + 150.f, y + 185.f, 200.f, 46.f, col, sf::Color(8, 12, 28));
    btnLogin.onClick = [this, role] { doLogin(role); };
    buttons.push_back(btnLogin);

    auto btnBack = makeButton("BACK", x + 370.f, y + 185.f, 120.f, 46.f,
        sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::MAIN_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doLogin(const std::string& role) {
    if (inputs.size() < 2) return;
    std::string idStr = inputs[0].value;
    std::string pw = inputs[1].value;

    int id = 0;
    if (!Validator::isPositiveInt(idStr, id)) {
        loginAttempts++;
        FileHandler::logSecurity(role, idStr, "FAILED");
        setStatus("Invalid ID. Attempt " + std::to_string(loginAttempts) + "/3", true);
        if (loginAttempts >= 3) { setStatus("Account locked. Contact admin.", true); goTo(Screen::MAIN_MENU); }
        return;
    }

    bool ok = false;
    if (role == "Patient") {
        Patient* p = patients.findById(id);
        if (p && p->getPassword() == pw) { currentPatient = p; ok = true; }
    }
    else if (role == "Doctor") {
        Doctor* d = doctors.findById(id);
        if (d && d->getPassword() == pw) { currentDoctor = d; ok = true; }
    }
    else {
        if (adminData.getId() == id && adminData.getPassword() == pw) ok = true;
    }

    if (ok) {
        loginAttempts = 0;
        FileHandler::logSecurity(role, idStr, "SUCCESS");
        if (role == "Patient") goTo(Screen::PATIENT_MENU);
        else if (role == "Doctor") goTo(Screen::DOCTOR_MENU);
        else goTo(Screen::ADMIN_MENU);
    }
    else {
        loginAttempts++;
        FileHandler::logSecurity(role, idStr, "FAILED");
        setStatus("Wrong credentials. Attempt " + std::to_string(loginAttempts) + "/3", true);
        if (loginAttempts >= 3) { setStatus("Account locked. Contact admin.", true); goTo(Screen::MAIN_MENU); }
    }
}

// ── Patient menu ──────────────────────────────────────────────────────────────
void GUI::buildPatientMenu() {
    struct Item { const char* lbl; Screen s; sf::Color c; };
    Item items[] = {
        {"1. Book Appointment",        Screen::BOOK_APPT,   PRIMARY},
        {"2. Cancel Appointment",      Screen::CANCEL_APPT, DANGER},
        {"3. View Appointments",       Screen::VIEW_APPTS,  CARD},
        {"4. Medical Records",         Screen::VIEW_RECORDS,CARD},
        {"5. View Bills",              Screen::VIEW_BILLS,  CARD},
        {"6. Pay Bill",                Screen::PAY_BILL,    SECONDARY},
        {"7. Top Up Balance",          Screen::TOPUP,       SUCCESS},
    };
    float x = 80.f, y = 130.f, bw = 500.f, bh = 48.f, gap = 12.f;
    for (int i = 0; i < 7; i++) {
        float bx = x + static_cast<float>(i / 4) * 560.f;
        float by = y + static_cast<float>(i % 4) * (bh + gap);
        auto btn = makeButton(items[i].lbl, bx, by, bw, bh, items[i].c,
            items[i].c == CARD ? TEXT_MAIN : sf::Color(8, 12, 28));
        Screen s = items[i].s;
        btn.onClick = [this, s] { goTo(s); };
        buttons.push_back(btn);
    }
    auto btnOut = makeButton("8. Logout", x + 560.f, y + 3.f * (bh + gap), bw, bh,
        sf::Color(60, 20, 20), DANGER);
    btnOut.onClick = [this] { currentPatient = nullptr; loginAttempts = 0; goTo(Screen::MAIN_MENU); };
    buttons.push_back(btnOut);
}

// ── Doctor menu ───────────────────────────────────────────────────────────────
void GUI::buildDoctorMenu() {
    struct Item { const char* lbl; Screen s; sf::Color c; };
    Item items[] = {
        {"1. Today's Appointments",    Screen::DOC_TODAY,        PRIMARY},
        {"2. Mark Complete",           Screen::DOC_COMPLETE,     SUCCESS},
        {"3. Mark No-Show",            Screen::DOC_NOSHOW,       DANGER},
        {"4. Write Prescription",      Screen::DOC_PRESCRIPTION, SECONDARY},
        {"5. Patient Medical History", Screen::DOC_HISTORY,      CARD},
    };
    float x = 300.f, y = 150.f, bw = 600.f, bh = 50.f, gap = 14.f;
    for (int i = 0; i < 5; i++) {
        auto btn = makeButton(items[i].lbl, x, y + static_cast<float>(i) * (bh + gap),
            bw, bh, items[i].c,
            items[i].c == CARD ? TEXT_MAIN : sf::Color(8, 12, 28));
        Screen s = items[i].s;
        btn.onClick = [this, s] { goTo(s); };
        buttons.push_back(btn);
    }
    auto btnOut = makeButton("6. Logout", x, y + 5.f * (bh + gap), bw, bh,
        sf::Color(60, 20, 20), DANGER);
    btnOut.onClick = [this] { currentDoctor = nullptr; goTo(Screen::MAIN_MENU); };
    buttons.push_back(btnOut);
}

// ── Admin menu ────────────────────────────────────────────────────────────────
void GUI::buildAdminMenu() {
    struct Item { const char* lbl; Screen s; sf::Color c; };
    Item items[] = {
        {"1. Add Doctor",            Screen::ADM_ADD_DOCTOR,    SUCCESS},
        {"2. Remove Doctor",         Screen::ADM_REMOVE_DOCTOR, DANGER},
        {"3. View All Patients",     Screen::ADM_VIEW_PATIENTS, PRIMARY},
        {"4. View All Doctors",      Screen::ADM_VIEW_DOCTORS,  PRIMARY},
        {"5. View All Appointments", Screen::ADM_VIEW_APPTS,    SECONDARY},
        {"6. Unpaid Bills",          Screen::ADM_UNPAID_BILLS,  sf::Color(230,120,40)},
        {"7. Discharge Patient",     Screen::ADM_DISCHARGE,     DANGER},
        {"8. Security Log",          Screen::ADM_SECURITY_LOG,  CARD},
        {"9. Daily Report",          Screen::ADM_DAILY_REPORT,  SECONDARY},
    };
    float x = 60.f, y = 130.f, bw = 380.f, bh = 46.f, gap = 10.f;
    for (int i = 0; i < 9; i++) {
        float bx = x + static_cast<float>(i / 5) * 420.f;
        float by = y + static_cast<float>(i % 5) * (bh + gap);
        auto btn = makeButton(items[i].lbl, bx, by, bw, bh, items[i].c,
            items[i].c == CARD ? TEXT_MAIN : sf::Color(8, 12, 28));
        Screen s = items[i].s;
        btn.onClick = [this, s] { goTo(s); };
        buttons.push_back(btn);
    }
    auto btnOut = makeButton("10. Logout", x + 420.f, y + 5.f * (bh + gap), bw, bh,
        sf::Color(60, 20, 20), DANGER);
    btnOut.onClick = [this] { goTo(Screen::MAIN_MENU); };
    buttons.push_back(btnOut);
}

// ── Book Appointment ──────────────────────────────────────────────────────────
void GUI::buildBookAppt() {
    // Build full doctor list
    std::string list = "=== ALL DOCTORS ===\n";
    list += "ID   Name                Specialization        Fee\n";
    list += std::string(65, '-') + "\n";
    for (int i = 0; i < doctors.size(); i++) {
        Doctor* d = doctors.get(i);
        std::ostringstream ss;
        ss << std::left << std::setw(5) << d->getId()
            << std::setw(20) << d->getName()
            << std::setw(22) << d->getSpecialization()
            << formatCurrency(d->getFee());
        list += ss.str() + "\n";
    }
    list += "\nAvailable Slots: 09:00 10:00 11:00 12:00 13:00 14:00 15:00 16:00\n";
    infoBody = list;

    float y = 510.f;
    inputs.push_back(makeInput("Specialization", 50.f, y, 260.f));
    inputs.push_back(makeInput("Doctor ID", 330.f, y, 180.f));
    inputs.push_back(makeInput("Date DD-MM-YYYY", 530.f, y, 260.f));
    inputs.push_back(makeInput("Time Slot", 810.f, y, 200.f));

    auto btnBook = makeButton("BOOK", 50.f, y + 100.f, 200.f, 46.f,
        PRIMARY, sf::Color(8, 12, 28));
    btnBook.onClick = [this] { doBookAppt(); };
    buttons.push_back(btnBook);

    auto btnBack = makeButton("BACK", 270.f, y + 100.f, 120.f, 46.f,
        sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::PATIENT_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doBookAppt() {
    if (inputs.size() < 4 || !currentPatient) return;
    std::string spec = inputs[0].value;
    std::string idStr = inputs[1].value;
    std::string dateStr = inputs[2].value;
    std::string slot = inputs[3].value;

    int docId = 0;
    if (!Validator::isPositiveInt(idStr, docId)) { setStatus("Invalid Doctor ID.", true); return; }
    Doctor* doc = doctors.findById(docId);
    if (!doc) { setStatus("Doctor not found.", true); return; }
    if (!spec.empty() && !Validator::strEqualCI(doc->getSpecialization(), spec)) {
        setStatus("Doctor specialization does not match.", true); return;
    }
    if (!Validator::isValidDate(dateStr)) {
        setStatus("Invalid date. Use DD-MM-YYYY (current year or later).", true); return;
    }
    if (!Validator::isValidTimeSlot(slot)) {
        setStatus("Invalid slot. Use: 09:00 10:00 11:00 12:00 13:00 14:00 15:00 16:00", true); return;
    }
    try {
        for (int i = 0; i < appointments.size(); i++) {
            Appointment* a = appointments.get(i);
            if (a->getDoctorId() == docId && a->getDate() == dateStr
                && a->getTimeSlot() == slot && a->getStatus() != "cancelled")
                throw SlotUnavailableException(slot.c_str());
        }
    }
    catch (SlotUnavailableException& e) { setStatus(e.what(), true); return; }

    try {
        if (currentPatient->getBalance() < doc->getFee())
            throw InsufficientFundsException(doc->getFee(), currentPatient->getBalance());
    }
    catch (InsufficientFundsException& e) { setStatus(e.what(), true); return; }

    int apptId = nextId(appointments);
    int billId = nextId(bills);
    std::string today = Validator::todayString();

    *currentPatient -= doc->getFee();
    Appointment appt(apptId, currentPatient->getId(), docId, dateStr, slot, "pending");
    Bill bill(billId, currentPatient->getId(), apptId, doc->getFee(), "unpaid", today);

    appointments.add(appt);
    bills.add(bill);
    FileHandler::appendAppointment(appt);
    FileHandler::appendBill(bill);
    FileHandler::savePatients(patients);

    setStatus("Booked! Appt ID:" + std::to_string(apptId) +
        "  Fee:" + formatCurrency(doc->getFee()) +
        "  Balance:" + formatCurrency(currentPatient->getBalance()));
    goTo(Screen::BOOK_APPT);
}

// ── Cancel Appointment ────────────────────────────────────────────────────────
void GUI::buildCancelAppt() {
    std::string list = "=== PENDING APPOINTMENTS ===\n";
    list += "ID    Doctor              Date         Slot\n";
    list += std::string(60, '-') + "\n";
    bool any = false;
    for (int i = 0; i < appointments.size(); i++) {
        Appointment* a = appointments.get(i);
        if (a->getPatientId() == currentPatient->getId() && a->getStatus() == "pending") {
            Doctor* d = doctors.findById(a->getDoctorId());
            std::ostringstream ss;
            ss << std::left << std::setw(6) << a->getAppointmentId()
                << std::setw(20) << (d ? d->getName() : "Unknown")
                << std::setw(13) << a->getDate()
                << a->getTimeSlot();
            list += ss.str() + "\n";
            any = true;
        }
    }
    if (!any) list += "No pending appointments.\n";
    infoBody = list;

    inputs.push_back(makeInput("Appointment ID to cancel", 200.f, 530.f, 400.f));
    auto btnCan = makeButton("CANCEL APPT", 200.f, 625.f, 220.f, 46.f, DANGER, sf::Color(8, 12, 28));
    btnCan.onClick = [this] { doCancelAppt(); };
    buttons.push_back(btnCan);
    auto btnBack = makeButton("BACK", 440.f, 625.f, 120.f, 46.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::PATIENT_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doCancelAppt() {
    if (inputs.empty() || !currentPatient) return;
    int apptId = 0;
    if (!Validator::isPositiveInt(inputs[0].value, apptId)) { setStatus("Invalid ID.", true); return; }
    Appointment* a = appointments.findById(apptId);
    if (!a || a->getPatientId() != currentPatient->getId() || a->getStatus() != "pending") {
        setStatus("Invalid appointment ID.", true); return;
    }
    Doctor* d = doctors.findById(a->getDoctorId());
    float fee = d ? d->getFee() : 0.f;
    a->setStatus("cancelled");
    *currentPatient += fee;
    for (int i = 0; i < bills.size(); i++) {
        Bill* b = bills.get(i);
        if (b->getAppointmentId() == apptId) { b->setStatus("cancelled"); break; }
    }
    FileHandler::saveAppointments(appointments);
    FileHandler::saveBills(bills);
    FileHandler::savePatients(patients);
    setStatus("Cancelled. Refunded " + formatCurrency(fee) +
        "  Balance: " + formatCurrency(currentPatient->getBalance()));
    goTo(Screen::CANCEL_APPT);
}

// ── View Appointments ─────────────────────────────────────────────────────────
void GUI::buildViewAppts() {
    std::vector<Appointment*> arr;
    for (int i = 0; i < appointments.size(); i++)
        if (appointments.get(i)->getPatientId() == currentPatient->getId())
            arr.push_back(appointments.get(i));
    // Bubble sort ascending by date
    for (int i = 0; i < (int)arr.size(); i++)
        for (int j = 0; j < (int)arr.size() - 1 - i; j++)
            if (Validator::compareDates(arr[j]->getDate(), arr[j + 1]->getDate()) > 0)
                std::swap(arr[j], arr[j + 1]);

    std::string list = "=== MY APPOINTMENTS (date asc) ===\n";
    list += "ID    Doctor              Spec              Date         Slot    Status\n";
    list += std::string(85, '-') + "\n";
    for (auto* a : arr) {
        Doctor* d = doctors.findById(a->getDoctorId());
        std::ostringstream ss;
        ss << std::left << std::setw(6) << a->getAppointmentId()
            << std::setw(20) << (d ? d->getName() : "Unknown")
            << std::setw(18) << (d ? d->getSpecialization() : "-")
            << std::setw(13) << a->getDate()
            << std::setw(8) << a->getTimeSlot()
            << a->getStatus();
        list += ss.str() + "\n";
    }
    if (arr.empty()) list += "No appointments found.\n";
    infoBody = list;

    auto btnBack = makeButton("BACK", 520.f, 695.f, 160.f, 42.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::PATIENT_MENU); };
    buttons.push_back(btnBack);
}

// ── View Medical Records ──────────────────────────────────────────────────────
void GUI::buildViewRecords() {
    std::vector<Prescription*> arr;
    for (int i = 0; i < prescriptions.size(); i++)
        if (prescriptions.get(i)->getPatientId() == currentPatient->getId())
            arr.push_back(prescriptions.get(i));
    // Sort descending
    for (int i = 0; i < (int)arr.size(); i++)
        for (int j = 0; j < (int)arr.size() - 1 - i; j++)
            if (Validator::compareDates(arr[j]->getDate(), arr[j + 1]->getDate()) < 0)
                std::swap(arr[j], arr[j + 1]);

    std::string list = "=== MEDICAL RECORDS (most recent first) ===\n";
    for (auto* pr : arr) {
        Doctor* d = doctors.findById(pr->getDoctorId());
        list += std::string(65, '-') + "\n";
        list += "Date: " + pr->getDate() + "  Dr. " + (d ? d->getName() : "Unknown") + "\n";
        list += "Medicines: " + pr->getMedicines() + "\n";
        list += "Notes:     " + pr->getNotes() + "\n";
    }
    if (arr.empty()) list += "No medical records found.\n";
    infoBody = list;

    auto btnBack = makeButton("BACK", 520.f, 695.f, 160.f, 42.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::PATIENT_MENU); };
    buttons.push_back(btnBack);
}

// ── View Bills ────────────────────────────────────────────────────────────────
void GUI::buildViewBills() {
    std::string list = "=== MY BILLS ===\n";
    list += "BillID  ApptID  Amount           Status      Date\n";
    list += std::string(65, '-') + "\n";
    float total = 0.f;
    bool any = false;
    for (int i = 0; i < bills.size(); i++) {
        Bill* b = bills.get(i);
        if (b->getPatientId() != currentPatient->getId()) continue;
        std::ostringstream ss;
        ss << std::left << std::setw(8) << b->getBillId()
            << std::setw(8) << b->getAppointmentId()
            << std::setw(17) << formatCurrency(b->getAmount())
            << std::setw(12) << b->getStatus()
            << b->getDate();
        list += ss.str() + "\n";
        if (b->getStatus() == "unpaid") total += b->getAmount();
        any = true;
    }
    if (!any) list += "No bills found.\n";
    list += std::string(65, '-') + "\n";
    list += "Total Outstanding: " + formatCurrency(total) + "\n";
    infoBody = list;

    auto btnBack = makeButton("BACK", 520.f, 695.f, 160.f, 42.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::PATIENT_MENU); };
    buttons.push_back(btnBack);
}

// ── Pay Bill ──────────────────────────────────────────────────────────────────
void GUI::buildPayBill() {
    std::string list = "=== UNPAID BILLS ===\n";
    list += "BillID  Amount           Date\n" + std::string(45, '-') + "\n";
    bool any = false;
    for (int i = 0; i < bills.size(); i++) {
        Bill* b = bills.get(i);
        if (b->getPatientId() == currentPatient->getId() && b->getStatus() == "unpaid") {
            std::ostringstream ss;
            ss << std::left << std::setw(8) << b->getBillId()
                << std::setw(17) << formatCurrency(b->getAmount())
                << b->getDate();
            list += ss.str() + "\n";
            any = true;
        }
    }
    if (!any) list += "No unpaid bills.\n";
    infoBody = list;

    inputs.push_back(makeInput("Bill ID to pay", 200.f, 540.f, 350.f));
    auto btnPay = makeButton("PAY BILL", 200.f, 635.f, 200.f, 46.f, SUCCESS, sf::Color(8, 12, 28));
    btnPay.onClick = [this] { doPayBill(); };
    buttons.push_back(btnPay);
    auto btnBack = makeButton("BACK", 420.f, 635.f, 120.f, 46.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::PATIENT_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doPayBill() {
    if (inputs.empty() || !currentPatient) return;
    int billId = 0;
    if (!Validator::isPositiveInt(inputs[0].value, billId)) { setStatus("Invalid ID.", true); return; }
    Bill* b = bills.findById(billId);
    if (!b || b->getPatientId() != currentPatient->getId() || b->getStatus() != "unpaid") {
        setStatus("Invalid or already paid bill.", true); return;
    }
    try {
        if (currentPatient->getBalance() < b->getAmount())
            throw InsufficientFundsException(b->getAmount(), currentPatient->getBalance());
    }
    catch (InsufficientFundsException& e) { setStatus(e.what(), true); return; }

    *currentPatient -= b->getAmount();
    b->setStatus("paid");
    FileHandler::saveBills(bills);
    FileHandler::savePatients(patients);
    setStatus("Bill paid! Balance: " + formatCurrency(currentPatient->getBalance()));
    goTo(Screen::PAY_BILL);
}

// ── Top Up ────────────────────────────────────────────────────────────────────
void GUI::buildTopUp() {
    inputs.push_back(makeInput("Amount to add (PKR)", 300.f, 220.f, 600.f));
    auto btnTop = makeButton("TOP UP", 400.f, 320.f, 200.f, 46.f, SUCCESS, sf::Color(8, 12, 28));
    btnTop.onClick = [this] { doTopUp(); };
    buttons.push_back(btnTop);
    auto btnBack = makeButton("BACK", 620.f, 320.f, 120.f, 46.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::PATIENT_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doTopUp() {
    if (inputs.empty() || !currentPatient) return;
    float amt = 0.f;
    try {
        if (!Validator::isPositiveFloat(inputs[0].value, amt))
            throw InvalidInputException("Amount must be a positive number.");
    }
    catch (InvalidInputException& e) { setStatus(e.what(), true); return; }
    *currentPatient += amt;
    FileHandler::savePatients(patients);
    setStatus("Balance updated! New balance: " + formatCurrency(currentPatient->getBalance()));
    goTo(Screen::PATIENT_MENU);
}

// ── Doctor: Today ─────────────────────────────────────────────────────────────
void GUI::buildDocToday() {
    std::string today = Validator::todayString();
    std::string list = "=== TODAY'S APPOINTMENTS (" + today + ") ===\n";
    list += "ID    Patient             Slot    Status\n" + std::string(55, '-') + "\n";

    std::vector<Appointment*> arr;
    for (int i = 0; i < appointments.size(); i++) {
        Appointment* a = appointments.get(i);
        if (a->getDoctorId() == currentDoctor->getId() && a->getDate() == today)
            arr.push_back(a);
    }
    for (int i = 0; i < (int)arr.size(); i++)
        for (int j = 0; j < (int)arr.size() - 1 - i; j++)
            if (arr[j]->getTimeSlot() > arr[j + 1]->getTimeSlot()) std::swap(arr[j], arr[j + 1]);

    for (auto* a : arr) {
        Patient* p = patients.findById(a->getPatientId());
        std::ostringstream ss;
        ss << std::left << std::setw(6) << a->getAppointmentId()
            << std::setw(20) << (p ? p->getName() : "Unknown")
            << std::setw(8) << a->getTimeSlot()
            << a->getStatus();
        list += ss.str() + "\n";
    }
    if (arr.empty()) list += "No appointments today.\n";
    infoBody = list;

    auto btnBack = makeButton("BACK", 520.f, 695.f, 160.f, 42.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::DOCTOR_MENU); };
    buttons.push_back(btnBack);
}

// ── Doctor: Mark Complete ─────────────────────────────────────────────────────
void GUI::buildDocComplete() {
    buildDocToday();
    inputs.push_back(makeInput("Appointment ID to complete", 200.f, 540.f, 400.f));
    auto btnOk = makeButton("MARK COMPLETE", 200.f, 635.f, 240.f, 46.f,
        SUCCESS, sf::Color(8, 12, 28));
    btnOk.onClick = [this] { doMarkComplete(); };
    buttons.push_back(btnOk);
    auto btnBack = makeButton("BACK", 460.f, 635.f, 120.f, 46.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::DOCTOR_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doMarkComplete() {
    if (inputs.empty() || !currentDoctor) return;
    int id = 0;
    if (!Validator::isPositiveInt(inputs[0].value, id)) { setStatus("Invalid ID.", true); return; }
    Appointment* a = appointments.findById(id);
    std::string today = Validator::todayString();
    if (!a || a->getDoctorId() != currentDoctor->getId()
        || a->getStatus() != "pending" || a->getDate() != today) {
        setStatus("Invalid appointment.", true); return;
    }
    a->setStatus("completed");
    FileHandler::saveAppointments(appointments);
    setStatus("Marked as completed.");
    goTo(Screen::DOC_COMPLETE);
}

// ── Doctor: Mark No-Show ──────────────────────────────────────────────────────
void GUI::buildDocNoShow() {
    buildDocToday();
    inputs.push_back(makeInput("Appointment ID for no-show", 200.f, 540.f, 400.f));
    auto btnOk = makeButton("MARK NO-SHOW", 200.f, 635.f, 230.f, 46.f,
        DANGER, sf::Color(8, 12, 28));
    btnOk.onClick = [this] { doMarkNoShow(); };
    buttons.push_back(btnOk);
    auto btnBack = makeButton("BACK", 450.f, 635.f, 120.f, 46.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::DOCTOR_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doMarkNoShow() {
    if (inputs.empty() || !currentDoctor) return;
    int id = 0;
    if (!Validator::isPositiveInt(inputs[0].value, id)) { setStatus("Invalid ID.", true); return; }
    Appointment* a = appointments.findById(id);
    std::string today = Validator::todayString();
    if (!a || a->getDoctorId() != currentDoctor->getId()
        || a->getStatus() != "pending" || a->getDate() != today) {
        setStatus("Invalid appointment.", true); return;
    }
    a->setStatus("noshow");
    for (int i = 0; i < bills.size(); i++) {
        Bill* b = bills.get(i);
        if (b->getAppointmentId() == id) { b->setStatus("cancelled"); break; }
    }
    FileHandler::saveAppointments(appointments);
    FileHandler::saveBills(bills);
    setStatus("Marked as no-show.");
    goTo(Screen::DOC_NOSHOW);
}

// ── Doctor: Write Prescription ────────────────────────────────────────────────
void GUI::buildDocPrescription() {
    float y = 140.f;
    inputs.push_back(makeInput("Completed Appointment ID", 50.f, y, 340.f));
    inputs.push_back(makeInput("Medicines (Name Dose;Name Dose)", 50.f, y + 85.f, 1100.f));
    inputs.push_back(makeInput("Notes (max 300 chars)", 50.f, y + 170.f, 1100.f));

    auto btnSave = makeButton("SAVE PRESCRIPTION", 50.f, y + 265.f, 280.f, 46.f,
        SECONDARY, sf::Color::White);
    btnSave.onClick = [this] { doWritePrescription(); };
    buttons.push_back(btnSave);
    auto btnBack = makeButton("BACK", 350.f, y + 265.f, 120.f, 46.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::DOCTOR_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doWritePrescription() {
    if (inputs.size() < 3 || !currentDoctor) return;
    std::string idStr = inputs[0].value;
    std::string medicines = inputs[1].value;
    std::string notes = inputs[2].value;
    if (medicines.size() > 499) medicines = medicines.substr(0, 499);
    if (notes.size() > 299) notes = notes.substr(0, 299);

    int apptId = 0;
    if (!Validator::isPositiveInt(idStr, apptId)) { setStatus("Invalid ID.", true); return; }
    Appointment* a = appointments.findById(apptId);
    if (!a || a->getDoctorId() != currentDoctor->getId() || a->getStatus() != "completed") {
        setStatus("Appointment not found or not completed.", true); return;
    }
    for (int i = 0; i < prescriptions.size(); i++)
        if (prescriptions.get(i)->getAppointmentId() == apptId) {
            setStatus("Prescription already written.", true); return;
        }

    int presId = nextId(prescriptions);
    Prescription pr(presId, apptId, a->getPatientId(),
        currentDoctor->getId(), a->getDate(), medicines, notes);
    prescriptions.add(pr);
    FileHandler::appendPrescription(pr);
    setStatus("Prescription saved. ID: " + std::to_string(presId));
    goTo(Screen::DOC_PRESCRIPTION);
}

// ── Doctor: Patient History ───────────────────────────────────────────────────
void GUI::buildDocHistory() {
    inputs.push_back(makeInput("Patient ID", 300.f, 160.f, 400.f));
    auto btnSrch = makeButton("VIEW HISTORY", 300.f, 260.f, 240.f, 46.f, PRIMARY, sf::Color(8, 12, 28));
    btnSrch.onClick = [this] { doViewHistory(); };
    buttons.push_back(btnSrch);
    auto btnBack = makeButton("BACK", 560.f, 260.f, 120.f, 46.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::DOCTOR_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doViewHistory() {
    if (inputs.empty() || !currentDoctor) return;
    int pid = 0;
    if (!Validator::isPositiveInt(inputs[0].value, pid)) { setStatus("Invalid ID.", true); return; }
    Patient* p = patients.findById(pid);
    if (!p) { setStatus("Access denied. You can only view records of your own patients.", true); return; }
    bool valid = false;
    for (int i = 0; i < appointments.size(); i++) {
        Appointment* a = appointments.get(i);
        if (a->getPatientId() == pid && a->getDoctorId() == currentDoctor->getId()
            && a->getStatus() == "completed") {
            valid = true; break;
        }
    }
    if (!valid) { setStatus("Access denied. You can only view records of your own patients.", true); return; }

    std::vector<Prescription*> arr;
    for (int i = 0; i < prescriptions.size(); i++) {
        Prescription* pr = prescriptions.get(i);
        if (pr->getPatientId() == pid && pr->getDoctorId() == currentDoctor->getId())
            arr.push_back(pr);
    }
    for (int i = 0; i < (int)arr.size(); i++)
        for (int j = 0; j < (int)arr.size() - 1 - i; j++)
            if (Validator::compareDates(arr[j]->getDate(), arr[j + 1]->getDate()) < 0)
                std::swap(arr[j], arr[j + 1]);

    std::string list = "=== HISTORY: " + p->getName() + " ===\n";
    for (auto* pr : arr) {
        list += std::string(60, '-') + "\n";
        list += "Date: " + pr->getDate() + "\n";
        list += "Medicines: " + pr->getMedicines() + "\n";
        list += "Notes:     " + pr->getNotes() + "\n";
    }
    if (arr.empty()) list += "No records found.\n";
    infoBody = list;
}

// ── Admin: Add Doctor ─────────────────────────────────────────────────────────
void GUI::buildAdmAddDoctor() {
    float y = 130.f;
    inputs.push_back(makeInput("Name", 50.f, y, 400.f));
    inputs.push_back(makeInput("Specialization", 480.f, y, 400.f));
    inputs.push_back(makeInput("Contact (11 digits)", 50.f, y + 85.f, 300.f));
    inputs.push_back(makeInput("Password (6+ chars)", 380.f, y + 85.f, 280.f));
    inputs.push_back(makeInput("Fee (PKR)", 690.f, y + 85.f, 220.f));

    auto btnAdd = makeButton("ADD DOCTOR", 400.f, y + 185.f, 240.f, 46.f,
        SUCCESS, sf::Color(8, 12, 28));
    btnAdd.onClick = [this] { doAddDoctor(); };
    buttons.push_back(btnAdd);
    auto btnBack = makeButton("BACK", 660.f, y + 185.f, 120.f, 46.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::ADMIN_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doAddDoctor() {
    if (inputs.size() < 5) return;
    std::string name = inputs[0].value;
    std::string spec = inputs[1].value;
    std::string cont = inputs[2].value;
    std::string pw = inputs[3].value;
    std::string feeStr = inputs[4].value;

    if (name.empty() || spec.empty()) { setStatus("Name and specialization required.", true); return; }
    if (!Validator::isValidContact(cont)) { setStatus("Contact: 11 numeric digits required.", true); return; }
    if (!Validator::isValidPassword(pw)) { setStatus("Password: 6+ chars required.", true); return; }
    float fee = 0.f;
    if (!Validator::isPositiveFloat(feeStr, fee)) { setStatus("Fee must be a positive number.", true); return; }

    int newId = nextId(doctors);
    Doctor d(newId, name, spec, cont, pw, fee);
    doctors.add(d);
    FileHandler::appendDoctor(d);
    setStatus("Doctor added! ID: " + std::to_string(newId));
    goTo(Screen::ADM_ADD_DOCTOR);
}

// ── Admin: Remove Doctor ──────────────────────────────────────────────────────
void GUI::buildAdmRemoveDoctor() {
    std::string list = "=== ALL DOCTORS ===\n";
    list += "ID   Name                Specialization        Fee\n" + std::string(60, '-') + "\n";
    for (int i = 0; i < doctors.size(); i++) {
        Doctor* d = doctors.get(i);
        std::ostringstream ss;
        ss << std::left << std::setw(5) << d->getId()
            << std::setw(20) << d->getName()
            << std::setw(22) << d->getSpecialization()
            << formatCurrency(d->getFee());
        list += ss.str() + "\n";
    }
    infoBody = list;

    inputs.push_back(makeInput("Doctor ID to remove", 200.f, 530.f, 360.f));
    auto btnRem = makeButton("REMOVE", 200.f, 625.f, 180.f, 46.f, DANGER, sf::Color(8, 12, 28));
    btnRem.onClick = [this] { doRemoveDoctor(); };
    buttons.push_back(btnRem);
    auto btnBack = makeButton("BACK", 400.f, 625.f, 120.f, 46.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::ADMIN_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doRemoveDoctor() {
    if (inputs.empty()) return;
    int docId = 0;
    if (!Validator::isPositiveInt(inputs[0].value, docId)) { setStatus("Invalid ID.", true); return; }
    for (int i = 0; i < appointments.size(); i++) {
        Appointment* a = appointments.get(i);
        if (a->getDoctorId() == docId && a->getStatus() == "pending") {
            setStatus("Cannot remove: doctor has pending appointments.", true); return;
        }
    }
    if (!doctors.removeById(docId)) { setStatus("Doctor not found.", true); return; }
    FileHandler::saveDoctors(doctors);
    setStatus("Doctor removed.");
    goTo(Screen::ADM_REMOVE_DOCTOR);
}

// ── Admin: View All Patients ──────────────────────────────────────────────────
void GUI::buildAdmViewPatients() {
    std::string list = "=== ALL PATIENTS ===\n";
    list += "ID   Name                Age  Gender  Contact       Balance          Unpaid\n";
    list += std::string(85, '-') + "\n";
    for (int i = 0; i < patients.size(); i++) {
        Patient* p = patients.get(i);
        int unpaid = 0;
        for (int j = 0; j < bills.size(); j++)
            if (bills.get(j)->getPatientId() == p->getId()
                && bills.get(j)->getStatus() == "unpaid") unpaid++;
        std::ostringstream ss;
        ss << std::left << std::setw(5) << p->getId()
            << std::setw(20) << p->getName()
            << std::setw(5) << p->getAge()
            << std::setw(8) << p->getGender()
            << std::setw(14) << p->getContact()
            << std::setw(17) << formatCurrency(p->getBalance())
            << unpaid;
        list += ss.str() + "\n";
    }
    if (patients.size() == 0) list += "No patients.\n";
    infoBody = list;
    auto btnBack = makeButton("BACK", 520.f, 695.f, 160.f, 42.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::ADMIN_MENU); };
    buttons.push_back(btnBack);
}

// ── Admin: View All Doctors ───────────────────────────────────────────────────
void GUI::buildAdmViewDoctors() {
    std::string list = "=== ALL DOCTORS ===\n";
    list += "ID   Name                Specialization        Contact       Fee\n";
    list += std::string(72, '-') + "\n";
    for (int i = 0; i < doctors.size(); i++) {
        Doctor* d = doctors.get(i);
        std::ostringstream ss;
        ss << std::left << std::setw(5) << d->getId()
            << std::setw(20) << d->getName()
            << std::setw(22) << d->getSpecialization()
            << std::setw(14) << d->getContact()
            << formatCurrency(d->getFee());
        list += ss.str() + "\n";
    }
    infoBody = list;
    auto btnBack = makeButton("BACK", 520.f, 695.f, 160.f, 42.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::ADMIN_MENU); };
    buttons.push_back(btnBack);
}

// ── Admin: View All Appointments ──────────────────────────────────────────────
void GUI::buildAdmViewAppts() {
    std::vector<Appointment*> arr;
    for (int i = 0; i < appointments.size(); i++) arr.push_back(appointments.get(i));
    for (int i = 0; i < (int)arr.size(); i++)
        for (int j = 0; j < (int)arr.size() - 1 - i; j++)
            if (Validator::compareDates(arr[j]->getDate(), arr[j + 1]->getDate()) < 0)
                std::swap(arr[j], arr[j + 1]);

    std::string list = "=== ALL APPOINTMENTS (date desc) ===\n";
    list += "ID    Patient             Doctor              Date         Slot    Status\n";
    list += std::string(82, '-') + "\n";
    for (auto* a : arr) {
        Patient* p = patients.findById(a->getPatientId());
        Doctor* d = doctors.findById(a->getDoctorId());
        std::ostringstream ss;
        ss << std::left << std::setw(6) << a->getAppointmentId()
            << std::setw(20) << (p ? p->getName() : "Unknown")
            << std::setw(20) << (d ? d->getName() : "Unknown")
            << std::setw(13) << a->getDate()
            << std::setw(8) << a->getTimeSlot()
            << a->getStatus();
        list += ss.str() + "\n";
    }
    if (arr.empty()) list += "No appointments.\n";
    infoBody = list;
    auto btnBack = makeButton("BACK", 520.f, 695.f, 160.f, 42.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::ADMIN_MENU); };
    buttons.push_back(btnBack);
}

// ── Admin: Unpaid Bills ───────────────────────────────────────────────────────
void GUI::buildAdmUnpaidBills() {
    std::string today = Validator::todayString();
    std::string list = "=== ALL UNPAID BILLS ===\n";
    list += "BillID  Patient             Amount           Date\n";
    list += std::string(65, '-') + "\n";
    for (int i = 0; i < bills.size(); i++) {
        Bill* b = bills.get(i);
        if (b->getStatus() != "unpaid") continue;
        Patient* p = patients.findById(b->getPatientId());
        std::string dateCol = b->getDate();
        if (Validator::daysBetween(b->getDate(), today) > 7)
            dateCol += " [OVERDUE]";
        std::ostringstream ss;
        ss << std::left << std::setw(8) << b->getBillId()
            << std::setw(20) << (p ? p->getName() : "Unknown")
            << std::setw(17) << formatCurrency(b->getAmount())
            << dateCol;
        list += ss.str() + "\n";
    }
    infoBody = list;
    auto btnBack = makeButton("BACK", 520.f, 695.f, 160.f, 42.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::ADMIN_MENU); };
    buttons.push_back(btnBack);
}

// ── Admin: Discharge ──────────────────────────────────────────────────────────
void GUI::buildAdmDischarge() {
    inputs.push_back(makeInput("Patient ID to discharge", 350.f, 220.f, 500.f));
    auto btnDis = makeButton("DISCHARGE", 420.f, 325.f, 200.f, 46.f, DANGER, sf::Color(8, 12, 28));
    btnDis.onClick = [this] { doDischarge(); };
    buttons.push_back(btnDis);
    auto btnBack = makeButton("BACK", 640.f, 325.f, 120.f, 46.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::ADMIN_MENU); };
    buttons.push_back(btnBack);
}

void GUI::doDischarge() {
    if (inputs.empty()) return;
    int pid = 0;
    if (!Validator::isPositiveInt(inputs[0].value, pid)) { setStatus("Invalid ID.", true); return; }
    if (!patients.findById(pid)) { setStatus("Patient not found.", true); return; }
    for (int i = 0; i < bills.size(); i++)
        if (bills.get(i)->getPatientId() == pid && bills.get(i)->getStatus() == "unpaid") {
            setStatus("Cannot discharge: patient has unpaid bills.", true); return;
        }
    for (int i = 0; i < appointments.size(); i++)
        if (appointments.get(i)->getPatientId() == pid
            && appointments.get(i)->getStatus() == "pending") {
            setStatus("Cannot discharge: patient has pending appointments.", true); return;
        }
    FileHandler::dischargePatient(pid, patients, appointments, bills, prescriptions);
    setStatus("Patient discharged and archived successfully.");
    goTo(Screen::ADM_DISCHARGE);
}

// ── Admin: Security Log ───────────────────────────────────────────────────────
void GUI::buildAdmSecurityLog() {
    infoBody = FileHandler::readSecurityLog();
    auto btnBack = makeButton("BACK", 520.f, 695.f, 160.f, 42.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::ADMIN_MENU); };
    buttons.push_back(btnBack);
}

// ── Admin: Daily Report ───────────────────────────────────────────────────────
void GUI::buildAdmDailyReport() {
    std::string today = Validator::todayString();
    int total = 0, pending = 0, completed = 0, noshow = 0, cancelled = 0;
    float revenue = 0.f;

    for (int i = 0; i < appointments.size(); i++) {
        Appointment* a = appointments.get(i);
        if (a->getDate() != today) continue;
        total++;
        if (a->getStatus() == "pending")   pending++;
        if (a->getStatus() == "completed") completed++;
        if (a->getStatus() == "noshow")    noshow++;
        if (a->getStatus() == "cancelled") cancelled++;
    }
    for (int i = 0; i < bills.size(); i++) {
        Bill* b = bills.get(i);
        if (b->getStatus() == "paid" && b->getDate() == today) revenue += b->getAmount();
    }

    std::string r = "=== DAILY REPORT: " + today + " ===\n\n";
    r += "Appointments today: " + std::to_string(total) + "\n";
    r += "  Pending:   " + std::to_string(pending) + "\n";
    r += "  Completed: " + std::to_string(completed) + "\n";
    r += "  No-show:   " + std::to_string(noshow) + "\n";
    r += "  Cancelled: " + std::to_string(cancelled) + "\n\n";
    r += "Revenue today: " + formatCurrency(revenue) + "\n\n";
    r += "--- Outstanding Unpaid Bills ---\n";
    r += "Patient              Total Owed\n" + std::string(40, '-') + "\n";
    for (int i = 0; i < patients.size(); i++) {
        Patient* p = patients.get(i);
        float owed = 0.f;
        for (int j = 0; j < bills.size(); j++)
            if (bills.get(j)->getPatientId() == p->getId()
                && bills.get(j)->getStatus() == "unpaid")
                owed += bills.get(j)->getAmount();
        if (owed > 0.f) {
            std::ostringstream ss;
            ss << std::left << std::setw(21) << p->getName() << formatCurrency(owed);
            r += ss.str() + "\n";
        }
    }
    r += "\n--- Doctor Summary Today ---\n";
    r += "Doctor               Done  Pending  NoShow\n" + std::string(45, '-') + "\n";
    for (int i = 0; i < doctors.size(); i++) {
        Doctor* d = doctors.get(i);
        int dc = 0, dp = 0, dn = 0;
        for (int j = 0; j < appointments.size(); j++) {
            Appointment* a = appointments.get(j);
            if (a->getDoctorId() != d->getId() || a->getDate() != today) continue;
            if (a->getStatus() == "completed") dc++;
            if (a->getStatus() == "pending")   dp++;
            if (a->getStatus() == "noshow")    dn++;
        }
        if (dc + dp + dn > 0) {
            std::ostringstream ss;
            ss << std::left << std::setw(21) << d->getName()
                << std::setw(6) << dc << std::setw(9) << dp << dn;
            r += ss.str() + "\n";
        }
    }
    infoBody = r;
    auto btnBack = makeButton("BACK", 520.f, 695.f, 160.f, 42.f, sf::Color(40, 50, 70), TEXT_MAIN);
    btnBack.onClick = [this] { goTo(Screen::ADMIN_MENU); };
    buttons.push_back(btnBack);
}

// ─────────────────────────────────────────────────────────────────────────────
// Render
// ─────────────────────────────────────────────────────────────────────────────
void GUI::render() {
    window.clear(BG);

    // ── Determine title/subtitle ───────────────────────────────────────────
    std::string title, sub;
    switch (currentScreen) {
    case Screen::MAIN_MENU:         title = "WELCOME";           sub = "Select your role"; break;
    case Screen::PATIENT_LOGIN:     title = "PATIENT LOGIN";     break;
    case Screen::DOCTOR_LOGIN:      title = "DOCTOR LOGIN";      break;
    case Screen::ADMIN_LOGIN:       title = "ADMIN LOGIN";       break;
    case Screen::PATIENT_MENU:
        title = "PATIENT MENU";
        if (currentPatient)
            sub = currentPatient->getName() + "  |  " +
            formatCurrency(currentPatient->getBalance());
        break;
    case Screen::DOCTOR_MENU:
        title = "DOCTOR MENU";
        if (currentDoctor)
            sub = "Dr." + currentDoctor->getName() +
            "  |  " + currentDoctor->getSpecialization();
        break;
    case Screen::ADMIN_MENU:        title = "ADMIN PANEL";        break;
    case Screen::BOOK_APPT:         title = "BOOK APPOINTMENT";   break;
    case Screen::CANCEL_APPT:       title = "CANCEL APPOINTMENT"; break;
    case Screen::VIEW_APPTS:        title = "MY APPOINTMENTS";    break;
    case Screen::VIEW_RECORDS:      title = "MEDICAL RECORDS";    break;
    case Screen::VIEW_BILLS:        title = "MY BILLS";           break;
    case Screen::PAY_BILL:          title = "PAY BILL";           break;
    case Screen::TOPUP:             title = "TOP UP BALANCE";     break;
    case Screen::DOC_TODAY:         title = "TODAY APPOINTMENTS"; break;
    case Screen::DOC_COMPLETE:      title = "MARK COMPLETE";      break;
    case Screen::DOC_NOSHOW:        title = "MARK NO-SHOW";       break;
    case Screen::DOC_PRESCRIPTION:  title = "WRITE PRESCRIPTION"; break;
    case Screen::DOC_HISTORY:       title = "PATIENT HISTORY";    break;
    case Screen::ADM_ADD_DOCTOR:    title = "ADD DOCTOR";         break;
    case Screen::ADM_REMOVE_DOCTOR: title = "REMOVE DOCTOR";      break;
    case Screen::ADM_VIEW_PATIENTS: title = "ALL PATIENTS";       break;
    case Screen::ADM_VIEW_DOCTORS:  title = "ALL DOCTORS";        break;
    case Screen::ADM_VIEW_APPTS:    title = "ALL APPOINTMENTS";   break;
    case Screen::ADM_UNPAID_BILLS:  title = "UNPAID BILLS";       break;
    case Screen::ADM_DISCHARGE:     title = "DISCHARGE PATIENT";  break;
    case Screen::ADM_SECURITY_LOG:  title = "SECURITY LOG";       break;
    case Screen::ADM_DAILY_REPORT:  title = "DAILY REPORT";       break;
    }
    drawHeader(title, sub);

    float contentTop = 78.f + (statusMsg.empty() ? 0.f : 28.f);

    // ── Main menu special layout ───────────────────────────────────────────
    if (currentScreen == Screen::MAIN_MENU) {
        drawText("MEDICORE HMS", 0.f, 120.f, 18u, PRIMARY, true, true, 1200.f);
        drawText("Full-featured hospital management", 0.f, 160.f, 8u, TEXT_DIM, false, true, 1200.f);

        // Draw 3 role cards
        struct Card { const char* lbl; const char* desc1; const char* desc2; sf::Color c; float x; };
        Card cards[] = {
            {"PATIENT",  "Book appointments",  "View medical records", PRIMARY,   80.f},
            {"DOCTOR",   "Manage schedule",    "Write prescriptions",  SECONDARY, 430.f},
            {"ADMIN",    "Full system access", "Reports & management", DANGER,    780.f},
        };
        for (auto& c : cards) {
            drawRect(c.x, 215.f, 320.f, 260.f, CARD, c.c, 2.f);
            drawText(c.lbl, c.x + 20.f, 235.f, 11u, c.c, true);
            drawText(c.desc1, c.x + 20.f, 275.f, 7u, TEXT_DIM);
            drawText(c.desc2, c.x + 20.f, 300.f, 7u, TEXT_DIM);
        }
        drawText("Default: Patient ID=1 pass=pass123  |  Doctor ID=1 pass=doc123  |  Admin ID=1 pass=admin123",
            0.f, 730.f, 6u, TEXT_DIM, false, true, 1200.f);
    }

    // ── Login screen hint ──────────────────────────────────────────────────
    if (currentScreen == Screen::PATIENT_LOGIN ||
        currentScreen == Screen::DOCTOR_LOGIN ||
        currentScreen == Screen::ADMIN_LOGIN) {
        drawRect(250.f, contentTop + 10.f, 700.f, 340.f, CARD, BORDER, 1.5f);
    }

    // ── Scrollable info body ───────────────────────────────────────────────
    if (!infoBody.empty()) {
        float paneTop = contentTop + 12.f;
        float paneH = 490.f;
        // Shrink pane if inputs/buttons are below
        if (!inputs.empty()) paneH = 420.f;
        drawScrollPane(infoBody, 30.f, paneTop, 1140.f, paneH);
    }

    // ── Draw inputs ────────────────────────────────────────────────────────
    for (auto& inp : inputs) {
        sf::RectangleShape box = inp.box;
        box.setOutlineColor(inp.active ? PRIMARY : BORDER);
        box.setOutlineThickness(inp.active ? 2.f : 1.5f);
        window.draw(box);
        window.draw(inp.labelText);

        std::string display = inp.value;
        if (inp.isPassword && !display.empty())
            display = std::string(display.size(), '*');

        sf::Text vt;
        vt.setFont(font);
        vt.setCharacterSize(9u);
        vt.setPosition(inp.box.getPosition().x + 8.f,
            inp.box.getPosition().y + 10.f);
        if (display.empty()) {
            vt.setString(inp.placeholder);
            vt.setFillColor(TEXT_DIM);
        }
        else {
            vt.setString(display);
            vt.setFillColor(TEXT_MAIN);
        }
        window.draw(vt);

        // Blinking cursor when active
        if (inp.active) {
            sf::RectangleShape cur(sf::Vector2f(2.f, 20.f));
            float cx = inp.box.getPosition().x + 8.f + vt.getLocalBounds().width + 2.f;
            cur.setPosition(cx, inp.box.getPosition().y + 8.f);
            cur.setFillColor(PRIMARY);
            window.draw(cur);
        }
    }

    // ── Draw buttons ───────────────────────────────────────────────────────
    for (auto& btn : buttons) {
        window.draw(btn.shape);
        window.draw(btn.label);
    }

    // Footer
    drawRect(0.f, 748.f, 1200.f, 32.f, sf::Color(8, 12, 28));
    drawText("MediCore v1.0  |  OOP Spring 2026  |  BCS-2G  |  Scroll: Mouse Wheel",
        0.f, 756.f, 6u, TEXT_DIM, false, true, 1200.f);

    window.display();
}