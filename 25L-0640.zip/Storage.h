#pragma once

template<typename T>
class Storage {
private:
    T* data;
    int count;
    int capacity;

    void grow() {
        capacity *= 2;
        T* nd = new T[capacity];
        for (int i = 0; i < count; i++) nd[i] = data[i];
        delete[] data;
        data = nd;
    }

public:
    Storage() : count(0), capacity(100) { data = new T[capacity]; }
    ~Storage() { delete[] data; }

    bool add(const T& item) {
        if (count >= capacity) grow();
        data[count++] = item;
        return true;
    }

    bool removeAt(int index) {
        if (index < 0 || index >= count) return false;
        for (int i = index; i < count - 1; i++) data[i] = data[i + 1];
        count--;
        return true;
    }

    T* get(int index) {
        if (index < 0 || index >= count) return nullptr;
        return &data[index];
    }

    T* getAll() { return data; }
    int size()   const { return count; }
    void clear() { count = 0; }

    T* findById(int id) {
        for (int i = 0; i < count; i++)
            if (data[i].getId() == id) return &data[i];
        return nullptr;
    }

    bool removeById(int id) {
        for (int i = 0; i < count; i++)
            if (data[i].getId() == id) return removeAt(i);
        return false;
    }
};