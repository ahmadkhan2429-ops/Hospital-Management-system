#pragma once
#include <exception>
#include <string>

class HospitalException : public std::exception {
protected:
    char message[300];
public:
    HospitalException(const char* msg) {
        int i = 0;
        while (msg[i] && i < 299) { message[i] = msg[i]; i++; }
        message[i] = '\0';
    }
    virtual const char* what() const noexcept override { return message; }
};

class FileNotFoundException : public HospitalException {
public:
    FileNotFoundException(const char* filename) : HospitalException("") {
        std::string s = "File not found: "; s += filename;
        int i = 0; while (s[i] && i < 299) { message[i] = s[i]; i++; } message[i] = '\0';
    }
};

class InsufficientFundsException : public HospitalException {
public:
    InsufficientFundsException(float required, float available) : HospitalException("") {
        std::string s = "Insufficient funds. Required: PKR " +
            std::to_string((int)required) + ", Available: PKR " + std::to_string((int)available);
        int i = 0; while (s[i] && i < 299) { message[i] = s[i]; i++; } message[i] = '\0';
    }
};

class InvalidInputException : public HospitalException {
public:
    InvalidInputException(const char* detail) : HospitalException("") {
        std::string s = "Invalid input: "; s += detail;
        int i = 0; while (s[i] && i < 299) { message[i] = s[i]; i++; } message[i] = '\0';
    }
};

class SlotUnavailableException : public HospitalException {
public:
    SlotUnavailableException(const char* slot) : HospitalException("") {
        std::string s = "Time slot "; s += slot; s += " is already booked.";
        int i = 0; while (s[i] && i < 299) { message[i] = s[i]; i++; } message[i] = '\0';
    }
};