#include "Person.h"

Person::Person() : id(0) {}
Person::Person(int id, const std::string& name, const std::string& password, const std::string& contact)
    : id(id), name(name), password(password), contact(contact) {
}

int         Person::getId()       const { return id; }
std::string Person::getName()     const { return name; }
std::string Person::getPassword() const { return password; }
std::string Person::getContact()  const { return contact; }

void Person::setId(int i) { id = i; }
void Person::setName(const std::string& n) { name = n; }
void Person::setPassword(const std::string& p) { password = p; }
void Person::setContact(const std::string& c) { contact = c; }
