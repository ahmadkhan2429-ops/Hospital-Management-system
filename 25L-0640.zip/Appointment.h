#pragma once
#include <string>
#include <ostream>

class Appointment {
private:
    int         appointmentId, patientId, doctorId;
    std::string date, timeSlot, status;
public:
    Appointment();
    Appointment(int aid, int pid, int did,
        const std::string& date, const std::string& slot, const std::string& status);

    int         getId()            const;
    int         getAppointmentId() const;
    int         getPatientId()     const;
    int         getDoctorId()      const;
    std::string getDate()          const;
    std::string getTimeSlot()      const;
    std::string getStatus()        const;

    void setStatus(const std::string& s);
    void setAppointmentId(int i);
    void setPatientId(int i);
    void setDoctorId(int i);
    void setDate(const std::string& d);
    void setTimeSlot(const std::string& t);

    bool operator==(const Appointment& o) const; // conflict detection
    friend std::ostream& operator<<(std::ostream& os, const Appointment& a);
};