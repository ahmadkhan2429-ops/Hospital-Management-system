#include "Validator.h"
#include <cctype>
#include <ctime>
#include <stdexcept>

// ?? String helpers ???????????????????????????????????????????????????????????

std::string Validator::toLowerStr(const std::string& s) {
    std::string r = s;
    for (auto& c : r) c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
    return r;
}

bool Validator::strEqualCI(const std::string& a, const std::string& b) {
    return toLowerStr(a) == toLowerStr(b);
}

// ?? Validation functions ??????????????????????????????????????????????????????

bool Validator::isValidPassword(const std::string& pw) {
    return pw.size() >= 6;
}

bool Validator::isValidContact(const std::string& c) {
    if (c.size() != 11) return false;
    for (char ch : c)
        if (!isdigit(static_cast<unsigned char>(ch))) return false;
    return true;
}

bool Validator::isPositiveFloat(const std::string& s, float& out) {
    if (s.empty()) return false;
    bool hasDot = false;
    for (size_t i = 0; i < s.size(); i++) {
        char c = s[i];
        if (c == '.' && !hasDot) { hasDot = true; continue; }
        if (!isdigit(static_cast<unsigned char>(c))) return false;
    }
    try { out = std::stof(s); }
    catch (...) { return false; }
    return out > 0.f;
}

bool Validator::isPositiveInt(const std::string& s, int& out) {
    if (s.empty()) return false;
    for (char c : s)
        if (!isdigit(static_cast<unsigned char>(c))) return false;
    try { out = std::stoi(s); }
    catch (...) { return false; }
    return out > 0;
}

bool Validator::isValidMenuChoice(const std::string& s, int mn, int mx, int& out) {
    if (s.empty()) return false;
    for (char c : s)
        if (!isdigit(static_cast<unsigned char>(c))) return false;
    try { out = std::stoi(s); }
    catch (...) { return false; }
    return out >= mn && out <= mx;
}

bool Validator::isValidTimeSlot(const std::string& slot) {
    static const char* slots[] = {
        "09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00"
    };
    for (int i = 0; i < 8; i++)
        if (slot == slots[i]) return true;
    return false;
}

bool Validator::isValidDate(const std::string& date) {
    if (date.size() != 10)        return false;
    if (date[2] != '-')           return false;
    if (date[5] != '-')           return false;
    for (int i = 0; i < 10; i++) {
        if (i == 2 || i == 5) continue;
        if (!isdigit(static_cast<unsigned char>(date[i]))) return false;
    }
    int day = std::stoi(date.substr(0, 2));
    int month = std::stoi(date.substr(3, 2));
    int year = std::stoi(date.substr(6, 4));
    if (day < 1 || day > 31)   return false;
    if (month < 1 || month > 12) return false;

    // ?? MSVC-safe: use localtime_s ??????????????????????????????
    time_t t = time(nullptr);
    struct tm lt = {};
#ifdef _WIN32
    localtime_s(&lt, &t);          // MSVC / Windows
#else
    localtime_r(&t, &lt);          // GCC / Linux
#endif
    int curYear = lt.tm_year + 1900;
    return year >= curYear;
}

// ?? Date utilities ????????????????????????????????????????????????????????????

std::string Validator::todayString() {
    time_t t = time(nullptr);
    struct tm lt = {};
#ifdef _WIN32
    localtime_s(&lt, &t);
#else
    localtime_r(&t, &lt);
#endif
    char buf[15];
    strftime(buf, sizeof(buf), "%d-%m-%Y", &lt);
    return std::string(buf);
}

// Convert DD-MM-YYYY to a comparable integer YYYYMMDD
static int dateToInt(const std::string& d) {
    if (d.size() < 10) return 0;
    int day = std::stoi(d.substr(0, 2));
    int month = std::stoi(d.substr(3, 2));
    int year = std::stoi(d.substr(6, 4));
    return year * 10000 + month * 100 + day;
}

int Validator::compareDates(const std::string& a, const std::string& b) {
    int ia = dateToInt(a), ib = dateToInt(b);
    return (ia < ib) ? -1 : (ia > ib) ? 1 : 0;
}

// Returns b - a in whole days
int Validator::daysBetween(const std::string& a, const std::string& b) {
    auto parse = [](const std::string& d) -> time_t {
        struct tm t = {};
        t.tm_mday = std::stoi(d.substr(0, 2));
        t.tm_mon = std::stoi(d.substr(3, 2)) - 1;
        t.tm_year = std::stoi(d.substr(6, 4)) - 1900;
        t.tm_isdst = -1;
        return mktime(&t);
        };
    double diff = difftime(parse(b), parse(a));
    return static_cast<int>(diff / 86400.0);
}