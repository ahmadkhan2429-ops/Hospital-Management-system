﻿#include "FileHandler.h"
#include "Validator.h"
#include "HospitalException.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <ctime>
#include <vector>

static const std::string DATA = "data/";

// ── CSV helper ───────────────────────────────────────────────────────────────
static std::vector<std::string> splitCSV(const std::string& line) {
    std::vector<std::string> tokens;
    std::string tok;
    for (char c : line) {
        if (c == ',') { tokens.push_back(tok); tok.clear(); }
        else          tok += c;
    }
    tokens.push_back(tok);
    return tokens;
}

// ── Ensure files exist and seed defaults ─────────────────────────────────────
void FileHandler::ensureDataFiles() {
    auto touch = [](const std::string& path) {
        std::ifstream f(path);
        if (!f.good()) std::ofstream o(path);
        };
    touch(DATA + "patients.txt");
    touch(DATA + "doctors.txt");
    touch(DATA + "appointments.txt");
    touch(DATA + "bills.txt");
    touch(DATA + "prescriptions.txt");
    touch(DATA + "security_log.txt");
    touch(DATA + "discharged.txt");

    // Admin
    {
        std::ifstream af(DATA + "admin.txt");
        if (!af.good() || af.peek() == std::ifstream::traits_type::eof()) {
            std::ofstream ao(DATA + "admin.txt");
            ao << "1,Admin,admin123\n";
        }
    }
    // Seed doctors
    {
        std::ifstream df(DATA + "doctors.txt");
        if (df.good() && df.peek() == std::ifstream::traits_type::eof()) {
            std::ofstream dout(DATA + "doctors.txt");
            dout << "1,Sara Khan,Cardiology,03111234567,doc123,1500.00\n";
            dout << "2,Ahmed Raza,Neurology,03211234567,doc456,2000.00\n";
            dout << "3,Fatima Malik,Orthopedics,03311234567,doc789,1200.00\n";
        }
    }
    // Seed patient
    {
        std::ifstream pf(DATA + "patients.txt");
        if (pf.good() && pf.peek() == std::ifstream::traits_type::eof()) {
            std::ofstream po(DATA + "patients.txt");
            po << "1,Ali Hassan,25,M,03001234567,pass123,10000.00\n";
        }
    }
}

// ── Load functions ────────────────────────────────────────────────────────────
void FileHandler::loadPatients(Storage<Patient>& store) {
    store.clear();
    std::ifstream f(DATA + "patients.txt");
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty()) continue;
        auto t = splitCSV(line);
        if (t.size() < 7) continue;
        Patient p(std::stoi(t[0]), t[1], std::stoi(t[2]),
            t[3], t[4], t[5], std::stof(t[6]));
        store.add(p);
    }
}

void FileHandler::loadDoctors(Storage<Doctor>& store) {
    store.clear();
    std::ifstream f(DATA + "doctors.txt");
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty()) continue;
        auto t = splitCSV(line);
        if (t.size() < 6) continue;
        Doctor d(std::stoi(t[0]), t[1], t[2], t[3], t[4], std::stof(t[5]));
        store.add(d);
    }
}

void FileHandler::loadAdmin(Admin& admin) {
    std::ifstream f(DATA + "admin.txt");
    std::string line;
    if (std::getline(f, line) && !line.empty()) {
        auto t = splitCSV(line);
        if (t.size() >= 3)
            admin = Admin(std::stoi(t[0]), t[1], t[2]);
    }
}

void FileHandler::loadAppointments(Storage<Appointment>& store) {
    store.clear();
    std::ifstream f(DATA + "appointments.txt");
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty()) continue;
        auto t = splitCSV(line);
        if (t.size() < 6) continue;
        Appointment a(std::stoi(t[0]), std::stoi(t[1]), std::stoi(t[2]),
            t[3], t[4], t[5]);
        store.add(a);
    }
}

void FileHandler::loadBills(Storage<Bill>& store) {
    store.clear();
    std::ifstream f(DATA + "bills.txt");
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty()) continue;
        auto t = splitCSV(line);
        if (t.size() < 6) continue;
        Bill b(std::stoi(t[0]), std::stoi(t[1]), std::stoi(t[2]),
            std::stof(t[3]), t[4], t[5]);
        store.add(b);
    }
}

void FileHandler::loadPrescriptions(Storage<Prescription>& store) {
    store.clear();
    std::ifstream f(DATA + "prescriptions.txt");
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty()) continue;
        auto t = splitCSV(line);
        if (t.size() < 7) continue;
        Prescription p(std::stoi(t[0]), std::stoi(t[1]),
            std::stoi(t[2]), std::stoi(t[3]),
            t[4], t[5], t[6]);
        store.add(p);
    }
}

// ── Save (rewrite whole file) ─────────────────────────────────────────────────
void FileHandler::savePatients(Storage<Patient>& store) {
    std::ofstream f(DATA + "patients.txt");
    for (int i = 0; i < store.size(); i++) {
        Patient* p = store.get(i);
        f << p->getId() << "," << p->getName() << ","
            << p->getAge() << "," << p->getGender() << ","
            << p->getContact() << "," << p->getPassword() << ","
            << std::fixed << std::setprecision(2) << p->getBalance() << "\n";
    }
}

void FileHandler::saveDoctors(Storage<Doctor>& store) {
    std::ofstream f(DATA + "doctors.txt");
    for (int i = 0; i < store.size(); i++) {
        Doctor* d = store.get(i);
        f << d->getId() << "," << d->getName() << ","
            << d->getSpecialization() << "," << d->getContact() << ","
            << d->getPassword() << ","
            << std::fixed << std::setprecision(2) << d->getFee() << "\n";
    }
}

void FileHandler::saveAppointments(Storage<Appointment>& store) {
    std::ofstream f(DATA + "appointments.txt");
    for (int i = 0; i < store.size(); i++) {
        Appointment* a = store.get(i);
        f << a->getAppointmentId() << "," << a->getPatientId() << ","
            << a->getDoctorId() << "," << a->getDate() << ","
            << a->getTimeSlot() << "," << a->getStatus() << "\n";
    }
}

void FileHandler::saveBills(Storage<Bill>& store) {
    std::ofstream f(DATA + "bills.txt");
    for (int i = 0; i < store.size(); i++) {
        Bill* b = store.get(i);
        f << b->getBillId() << "," << b->getPatientId() << ","
            << b->getAppointmentId() << ","
            << std::fixed << std::setprecision(2) << b->getAmount() << ","
            << b->getStatus() << "," << b->getDate() << "\n";
    }
}

void FileHandler::savePrescriptions(Storage<Prescription>& store) {
    std::ofstream f(DATA + "prescriptions.txt");
    for (int i = 0; i < store.size(); i++) {
        Prescription* p = store.get(i);
        f << p->getPrescriptionId() << "," << p->getAppointmentId() << ","
            << p->getPatientId() << "," << p->getDoctorId() << ","
            << p->getDate() << "," << p->getMedicines() << "," << p->getNotes() << "\n";
    }
}

// ── Append functions ──────────────────────────────────────────────────────────
void FileHandler::appendPatient(const Patient& p) {
    std::ofstream f(DATA + "patients.txt", std::ios::app);
    f << p.getId() << "," << p.getName() << ","
        << p.getAge() << "," << p.getGender() << ","
        << p.getContact() << "," << p.getPassword() << ","
        << std::fixed << std::setprecision(2) << p.getBalance() << "\n";
}

void FileHandler::appendDoctor(const Doctor& d) {
    std::ofstream f(DATA + "doctors.txt", std::ios::app);
    f << d.getId() << "," << d.getName() << ","
        << d.getSpecialization() << "," << d.getContact() << ","
        << d.getPassword() << ","
        << std::fixed << std::setprecision(2) << d.getFee() << "\n";
}

void FileHandler::appendAppointment(const Appointment& a) {
    std::ofstream f(DATA + "appointments.txt", std::ios::app);
    f << a.getAppointmentId() << "," << a.getPatientId() << ","
        << a.getDoctorId() << "," << a.getDate() << ","
        << a.getTimeSlot() << "," << a.getStatus() << "\n";
}

void FileHandler::appendBill(const Bill& b) {
    std::ofstream f(DATA + "bills.txt", std::ios::app);
    f << b.getBillId() << "," << b.getPatientId() << ","
        << b.getAppointmentId() << ","
        << std::fixed << std::setprecision(2) << b.getAmount() << ","
        << b.getStatus() << "," << b.getDate() << "\n";
}

void FileHandler::appendPrescription(const Prescription& pr) {
    std::ofstream f(DATA + "prescriptions.txt", std::ios::app);
    f << pr.getPrescriptionId() << "," << pr.getAppointmentId() << ","
        << pr.getPatientId() << "," << pr.getDoctorId() << ","
        << pr.getDate() << "," << pr.getMedicines() << "," << pr.getNotes() << "\n";
}

// ── Security log ──────────────────────────────────────────────────────────────
void FileHandler::logSecurity(const std::string& role,
    const std::string& enteredId,
    const std::string& result) {
    std::ofstream f(DATA + "security_log.txt", std::ios::app);

    time_t t = time(nullptr);
    struct tm lt = {};
#ifdef _WIN32
    localtime_s(&lt, &t);     // MSVC safe
#else
    localtime_r(&t, &lt);     // GCC / Linux safe
#endif
    char buf[30];
    strftime(buf, sizeof(buf), "%d-%m-%Y %H:%M:%S", &lt);
    f << buf << "," << role << "," << enteredId << "," << result << "\n";
}

std::string FileHandler::readSecurityLog() {
    std::ifstream f(DATA + "security_log.txt");
    std::string all, line;
    while (std::getline(f, line)) all += line + "\n";
    return all.empty() ? "No security events logged." : all;
}

// ── Discharge ─────────────────────────────────────────────────────────────────
void FileHandler::dischargePatient(int patientId,
    Storage<Patient>& patients,
    Storage<Appointment>& appointments,
    Storage<Bill>& bills,
    Storage<Prescription>& prescriptions) {
    std::ofstream arc(DATA + "discharged.txt", std::ios::app);

    Patient* p = patients.findById(patientId);
    if (p) {
        arc << "PATIENT," << p->getId() << "," << p->getName() << ","
            << p->getAge() << "," << p->getGender() << ","
            << p->getContact() << "," << p->getPassword() << ","
            << std::fixed << std::setprecision(2) << p->getBalance() << "\n";
    }
    for (int i = 0; i < appointments.size(); i++) {
        Appointment* a = appointments.get(i);
        if (a->getPatientId() == patientId) {
            arc << "APPOINTMENT," << a->getAppointmentId() << ","
                << a->getPatientId() << "," << a->getDoctorId() << ","
                << a->getDate() << "," << a->getTimeSlot() << ","
                << a->getStatus() << "\n";
        }
    }
    for (int i = 0; i < bills.size(); i++) {
        Bill* b = bills.get(i);
        if (b->getPatientId() == patientId) {
            arc << "BILL," << b->getBillId() << "," << b->getPatientId() << ","
                << b->getAppointmentId() << ","
                << std::fixed << std::setprecision(2) << b->getAmount() << ","
                << b->getStatus() << "," << b->getDate() << "\n";
        }
    }
    for (int i = 0; i < prescriptions.size(); i++) {
        Prescription* pr = prescriptions.get(i);
        if (pr->getPatientId() == patientId) {
            arc << "PRESCRIPTION," << pr->getPrescriptionId() << ","
                << pr->getAppointmentId() << "," << pr->getPatientId() << ","
                << pr->getDoctorId() << "," << pr->getDate() << ","
                << pr->getMedicines() << "," << pr->getNotes() << "\n";
        }
    }

    // Remove from stores
    patients.removeById(patientId);
    for (int i = appointments.size() - 1; i >= 0; i--)
        if (appointments.get(i)->getPatientId() == patientId) appointments.removeAt(i);
    for (int i = bills.size() - 1; i >= 0; i--)
        if (bills.get(i)->getPatientId() == patientId) bills.removeAt(i);
    for (int i = prescriptions.size() - 1; i >= 0; i--)
        if (prescriptions.get(i)->getPatientId() == patientId) prescriptions.removeAt(i);

    savePatients(patients);
    saveAppointments(appointments);
    saveBills(bills);
    savePrescriptions(prescriptions);
}