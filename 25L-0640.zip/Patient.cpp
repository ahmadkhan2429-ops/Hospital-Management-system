#include "Patient.h"
#include <iostream>

Patient::Patient() : Person(), age(0), balance(0.f) {}
Patient::Patient(int id, const std::string& name, int age, const std::string& gender,
    const std::string& contact, const std::string& password, float balance)
    : Person(id, name, password, contact), age(age), gender(gender), balance(balance) {
}

int         Patient::getAge()    const { return age; }
std::string Patient::getGender() const { return gender; }
float       Patient::getBalance()const { return balance; }
void Patient::setAge(int a) { age = a; }
void Patient::setGender(const std::string& g) { gender = g; }
void Patient::setBalance(float b) { balance = b; }

Patient& Patient::operator+=(float amount) { balance += amount; return *this; }
Patient& Patient::operator-=(float amount) { balance -= amount; return *this; }
bool Patient::operator==(const Patient& o) const { return id == o.id; }

std::ostream& operator<<(std::ostream& os, const Patient& p) {
    os << "[" << p.id << "] " << p.name << " | Age:" << p.age
        << " | " << p.gender << " | " << p.contact << " | PKR " << p.balance;
    return os;
}

void Patient::displayMenu() { /* handled in GUI */ }
std::string Patient::getRole() const { return "Patient"; }
