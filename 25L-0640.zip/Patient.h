#pragma once
#include "Person.h"
#include <ostream>

class Patient : public Person {
private:
    int         age;
    std::string gender;
    float       balance;
public:
    Patient();
    Patient(int id, const std::string& name, int age, const std::string& gender,
        const std::string& contact, const std::string& password, float balance);

    int         getAge()    const;
    std::string getGender() const;
    float       getBalance()const;
    void setAge(int a);
    void setGender(const std::string& g);
    void setBalance(float b);

    Patient& operator+=(float amount);
    Patient& operator-=(float amount);
    bool     operator==(const Patient& o) const;
    friend std::ostream& operator<<(std::ostream& os, const Patient& p);

    void        displayMenu() override;
    std::string getRole()     const override;
};