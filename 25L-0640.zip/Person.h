#pragma once
#include <string>

class Person {
protected:
    int id;
    std::string name;
    std::string password;
    std::string contact;
public:
    Person();
    Person(int id, const std::string& name, const std::string& password, const std::string& contact);
    virtual ~Person() = default;

    int         getId()       const;
    std::string getName()     const;
    std::string getPassword() const;
    std::string getContact()  const;

    void setId(int i);
    void setName(const std::string& n);
    void setPassword(const std::string& p);
    void setContact(const std::string& c);

    virtual void        displayMenu() = 0;
    virtual std::string getRole()     const = 0;
};