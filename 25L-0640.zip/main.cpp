#include "GUI.h"
#include "FileHandler.h"
#include "HospitalException.h"
#include "Storage.h"
#include "Patient.h"
#include "Doctor.h"
#include "Admin.h"
#include "Appointment.h"
#include "Bill.h"
#include "Prescription.h"
#include <iostream>

int main() {
    // Ensure data directory and seed files exist
    FileHandler::ensureDataFiles();

    // Global data stores
    Storage<Patient>     patients;
    Storage<Doctor>      doctors;
    Storage<Appointment> appointments;
    Storage<Bill>        bills;
    Storage<Prescription>prescriptions;
    Admin                admin;

    // Load all data from files
    try {
        FileHandler::loadPatients(patients);
        FileHandler::loadDoctors(doctors);
        FileHandler::loadAdmin(admin);
        FileHandler::loadAppointments(appointments);
        FileHandler::loadBills(bills);
        FileHandler::loadPrescriptions(prescriptions);
    }
    catch (FileNotFoundException& e) {
        std::cerr << "Startup error: " << e.what() << std::endl;
        return 1;
    }

    // Launch SFML GUI � all logic lives in GUI.cpp
    GUI gui(patients, doctors, appointments, bills, prescriptions, admin);
    gui.run();

    return 0;
}
