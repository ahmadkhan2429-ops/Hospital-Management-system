#pragma once
#include "Storage.h"
#include "Patient.h"
#include "Doctor.h"
#include "Admin.h"
#include "Appointment.h"
#include "Bill.h"
#include "Prescription.h"
#include <string>

class FileHandler {
public:
    static void loadPatients(Storage<Patient>& store);
    static void loadDoctors(Storage<Doctor>& store);
    static void loadAdmin(Admin& admin);
    static void loadAppointments(Storage<Appointment>& store);
    static void loadBills(Storage<Bill>& store);
    static void loadPrescriptions(Storage<Prescription>& store);

    static void savePatients(Storage<Patient>& store);
    static void saveDoctors(Storage<Doctor>& store);
    static void saveAppointments(Storage<Appointment>& store);
    static void saveBills(Storage<Bill>& store);
    static void savePrescriptions(Storage<Prescription>& store);

    static void appendPatient(const Patient& p);
    static void appendDoctor(const Doctor& d);
    static void appendAppointment(const Appointment& a);
    static void appendBill(const Bill& b);
    static void appendPrescription(const Prescription& pr);

    static void        logSecurity(const std::string& role,
        const std::string& enteredId,
        const std::string& result);
    static std::string readSecurityLog();

    static void dischargePatient(int patientId,
        Storage<Patient>& patients,
        Storage<Appointment>& appointments,
        Storage<Bill>& bills,
        Storage<Prescription>& prescriptions);

    static void ensureDataFiles();
};