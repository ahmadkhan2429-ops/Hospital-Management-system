#pragma once
#include "Person.h"

class Admin : public Person {
public:
    Admin();
    Admin(int id, const std::string& name, const std::string& password);
    void        displayMenu() override;
    std::string getRole()     const override;
};