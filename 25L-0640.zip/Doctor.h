#pragma once
#include "Person.h"
#include <ostream>

class Doctor : public Person {
private:
    std::string specialization;
    float       fee;
public:
    Doctor();
    Doctor(int id, const std::string& name, const std::string& spec,
        const std::string& contact, const std::string& password, float fee);

    std::string getSpecialization() const;
    float       getFee()            const;
    void setSpecialization(const std::string& s);
    void setFee(float f);

    bool operator==(const Doctor& o) const;
    friend std::ostream& operator<<(std::ostream& os, const Doctor& d);

    void        displayMenu() override;
    std::string getRole()     const override;
};