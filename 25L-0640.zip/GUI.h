#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#include <functional>
#include "Storage.h"
#include "Patient.h"
#include "Doctor.h"
#include "Admin.h"
#include "Appointment.h"
#include "Bill.h"
#include "Prescription.h"

enum class Screen {
    MAIN_MENU,
    PATIENT_LOGIN, DOCTOR_LOGIN, ADMIN_LOGIN,
    PATIENT_MENU, DOCTOR_MENU, ADMIN_MENU,
    BOOK_APPT, CANCEL_APPT, VIEW_APPTS, VIEW_RECORDS, VIEW_BILLS, PAY_BILL, TOPUP,
    DOC_TODAY, DOC_COMPLETE, DOC_NOSHOW, DOC_PRESCRIPTION, DOC_HISTORY,
    ADM_ADD_DOCTOR, ADM_REMOVE_DOCTOR, ADM_VIEW_PATIENTS, ADM_VIEW_DOCTORS,
    ADM_VIEW_APPTS, ADM_UNPAID_BILLS, ADM_DISCHARGE, ADM_SECURITY_LOG, ADM_DAILY_REPORT
};

struct UIButton {
    sf::RectangleShape shape;
    sf::Text           label;
    std::function<void()> onClick;
    sf::Color normalColor, hoverColor;
    bool hovered = false;
};

struct UIInput {
    sf::RectangleShape box;
    sf::Text           labelText;
    std::string        value;
    std::string        placeholder;
    bool               active = false;
    bool               isPassword = false;
};

class GUI {
private:
    sf::RenderWindow window;
    sf::Font         font;       // PressStart2P-Regular.ttf

    // ?? Colour palette ??????????????????????????????????????????
    const sf::Color BG{ 10,  14,  30 };
    const sf::Color CARD{ 20,  28,  50 };
    const sf::Color PRIMARY{ 0,  220, 180 };
    const sf::Color SECONDARY{ 120, 80,  240 };
    const sf::Color DANGER{ 230,  50,  50 };
    const sf::Color SUCCESS{ 30, 200, 100 };
    const sf::Color TEXT_MAIN{ 220, 230, 245 };
    const sf::Color TEXT_DIM{ 90, 110, 140 };
    const sf::Color BORDER{ 40,  55,  80 };

    // ?? State ???????????????????????????????????????????????????
    Screen      currentScreen;
    std::string infoBody;
    std::string statusMsg;
    bool        statusIsError = false;

    Patient* currentPatient = nullptr;
    Doctor* currentDoctor = nullptr;
    int      loginAttempts = 0;

    Storage<Patient>& patients;
    Storage<Doctor>& doctors;
    Storage<Appointment>& appointments;
    Storage<Bill>& bills;
    Storage<Prescription>& prescriptions;
    Admin& adminData;

    std::vector<UIInput>  inputs;
    std::vector<UIButton> buttons;
    int   activeInputIdx = -1;
    float scrollY = 0.f;
    float maxScrollY = 0.f;

    // sub-flow helpers
    std::string tmpSpec;

    // ?? Private helpers ?????????????????????????????????????????
    void drawRect(float x, float y, float w, float h, sf::Color fill,
        sf::Color borderCol = { 0,0,0,0 }, float borderThick = 0.f);
    void drawText(const std::string& txt, float x, float y,
        unsigned sz, sf::Color col,
        bool bold = false, bool center = false, float maxW = 0.f);
    void drawHeader(const std::string& title, const std::string& sub = "");
    void drawInputs();
    void drawButtons();
    void drawScrollPane(const std::string& content,
        float x, float y, float w, float h);

    UIButton makeButton(const std::string& lbl,
        float x, float y, float w, float h,
        sf::Color bg = { 0,220,180 },
        sf::Color fg = { 10,14,30 });
    UIInput  makeInput(const std::string& lbl,
        float x, float y, float w,
        const std::string& ph = "",
        bool password = false);

    void clearUI();
    void updateHovers(sf::Vector2i mouse);
    void processClicks(sf::Vector2i mouse);
    void goTo(Screen s);
    void setStatus(const std::string& msg, bool error = false);

    // next available ID helpers
    template<typename T> int nextId(Storage<T>& s);

    std::string formatCurrency(float f);

    // ?? Screen builders ?????????????????????????????????????????
    void buildMainMenu();
    void buildLoginScreen(const std::string& role);
    void buildPatientMenu();
    void buildDoctorMenu();
    void buildAdminMenu();

    void buildBookAppt();
    void buildCancelAppt();
    void buildViewAppts();
    void buildViewRecords();
    void buildViewBills();
    void buildPayBill();
    void buildTopUp();

    void buildDocToday();
    void buildDocComplete();
    void buildDocNoShow();
    void buildDocPrescription();
    void buildDocHistory();

    void buildAdmAddDoctor();
    void buildAdmRemoveDoctor();
    void buildAdmViewPatients();
    void buildAdmViewDoctors();
    void buildAdmViewAppts();
    void buildAdmUnpaidBills();
    void buildAdmDischarge();
    void buildAdmSecurityLog();
    void buildAdmDailyReport();

    // ?? Action handlers ?????????????????????????????????????????
    void doLogin(const std::string& role);
    void doBookAppt();
    void doCancelAppt();
    void doPayBill();
    void doTopUp();
    void doMarkComplete();
    void doMarkNoShow();
    void doWritePrescription();
    void doAddDoctor();
    void doRemoveDoctor();
    void doDischarge();
    void doViewHistory();

    void render();

public:
    GUI(Storage<Patient>& patients, Storage<Doctor>& doctors,
        Storage<Appointment>& appts, Storage<Bill>& bills,
        Storage<Prescription>& prescs, Admin& admin);
    void run();
};