#include "Bill.h"
Bill::Bill() : billId(0), patientId(0), appointmentId(0), amount(0.f) {}
Bill::Bill(int bid, int pid, int aid, float amount, const std::string& status, const std::string& date)
    : billId(bid), patientId(pid), appointmentId(aid), amount(amount), status(status), date(date) {
}

int         Bill::getId()            const { return billId; }
int         Bill::getBillId()        const { return billId; }
int         Bill::getPatientId()     const { return patientId; }
int         Bill::getAppointmentId() const { return appointmentId; }
float       Bill::getAmount()        const { return amount; }
std::string Bill::getStatus()        const { return status; }
std::string Bill::getDate()          const { return date; }

void Bill::setBillId(int i) { billId = i; }
void Bill::setStatus(const std::string& s) { status = s; }
void Bill::setAmount(float a) { amount = a; }
void Bill::setPatientId(int i) { patientId = i; }
void Bill::setAppointmentId(int i) { appointmentId = i; }
void Bill::setDate(const std::string& d) { date = d; }
