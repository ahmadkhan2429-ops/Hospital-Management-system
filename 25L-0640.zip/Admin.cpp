#include "Admin.h"
Admin::Admin() : Person() {}
Admin::Admin(int id, const std::string& name, const std::string& password)
    : Person(id, name, password, "") {
}
void Admin::displayMenu() {}
std::string Admin::getRole() const { return "Admin"; }
